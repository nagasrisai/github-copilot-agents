# Agent: Test Generator

## Role
Generate comprehensive unit tests with JUnit 5 and Mockito.
Minimum 85% line coverage, target 90%. Every business rule gets its own test.

## Inputs
- Generated source code from `code-generator`
- `requirement.md` acceptance criteria — each AC must have at least one test
- `instructions/testing-standards.md`

## Test Generation Rules
1. One test class per production class
2. Cover: happy path, all error paths, edge cases, boundary values
3. Each AC from requirement.md must map to at least one test method
4. Use `@DisplayName` for human-readable test names
5. Follow Arrange / Act / Assert strictly

## Controller Test Template
```java
/**
 * Unit tests for {@link <Resource>Controller}.
 */
@WebMvcTest(<Resource>Controller.class)
@AutoConfigureMockMvc
class <Resource>ControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private <Resource>Service <resource>Service;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @DisplayName("should return 201 Created when valid request is submitted")
    @WithMockUser(roles = "USER")
    void shouldReturn201WhenValidRequest() throws Exception {
        // Arrange
        <Resource>Request request = new <Resource>Request("test@example.com", ResourceType.STANDARD);
        <Resource>Response response = new <Resource>Response(1L, "test@example.com", ResourceType.STANDARD, LocalDateTime.now());
        when(<resource>Service.create(any())).thenReturn(response);

        // Act & Assert
        mockMvc.perform(post("/api/v1/<resources>")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isCreated())
            .andExpect(jsonPath("$.id").value(1L))
            .andExpect(jsonPath("$.email").value("test@example.com"));

        verify(<resource>Service, times(1)).create(any(<Resource>Request.class));
    }

    @Test
    @DisplayName("should return 400 Bad Request when email is blank")
    @WithMockUser(roles = "USER")
    void shouldReturn400WhenEmailIsBlank() throws Exception {
        // Arrange
        <Resource>Request request = new <Resource>Request("", ResourceType.STANDARD);

        // Act & Assert
        mockMvc.perform(post("/api/v1/<resources>")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isBadRequest())
            .andExpect(jsonPath("$.code").value("VALIDATION_FAILED"));

        verifyNoInteractions(<resource>Service);
    }

    @Test
    @DisplayName("should return 401 Unauthorized when not authenticated")
    void shouldReturn401WhenNotAuthenticated() throws Exception {
        // Arrange
        <Resource>Request request = new <Resource>Request("test@example.com", ResourceType.STANDARD);

        // Act & Assert
        mockMvc.perform(post("/api/v1/<resources>")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("should return 403 Forbidden when user lacks required role")
    @WithMockUser(roles = "READONLY")
    void shouldReturn403WhenInsufficientRole() throws Exception {
        // Arrange
        <Resource>Request request = new <Resource>Request("test@example.com", ResourceType.STANDARD);

        // Act & Assert
        mockMvc.perform(post("/api/v1/<resources>")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(request)))
            .andExpect(status().isForbidden());
    }
}
```

## Service Test Template
```java
/**
 * Unit tests for {@link <Resource>ServiceImpl}.
 */
@ExtendWith(MockitoExtension.class)
class <Resource>ServiceImplTest {

    @Mock
    private <Resource>Repository <resource>Repository;

    @Mock
    private <Event>EventProducer eventProducer;

    @InjectMocks
    private <Resource>ServiceImpl <resource>Service;

    @Test
    @DisplayName("should create <resource> and return response when valid request")
    void shouldCreate<Resource>WhenValidRequest() {
        // Arrange
        <Resource>Request request = new <Resource>Request("test@example.com", ResourceType.STANDARD);
        <Resource>Entity savedEntity = <Resource>Entity.builder()
            .id(1L).email("test@example.com").status(Status.ACTIVE).build();
        when(<resource>Repository.save(any())).thenReturn(savedEntity);

        // Act
        <Resource>Response result = <resource>Service.create(request);

        // Assert
        assertThat(result).isNotNull();
        assertThat(result.id()).isEqualTo(1L);
        assertThat(result.email()).isEqualTo("test@example.com");
        verify(<resource>Repository).save(any(<Resource>Entity.class));
    }

    @Test
    @DisplayName("should throw <Resource>NotFoundException when id does not exist")
    void shouldThrow<Resource>NotFoundExceptionWhenIdNotFound() {
        // Arrange
        Long nonExistentId = 999L;
        when(<resource>Repository.findById(nonExistentId)).thenReturn(Optional.empty());

        // Act & Assert
        assertThatThrownBy(() -> <resource>Service.findById(nonExistentId))
            .isInstanceOf(<Resource>NotFoundException.class)
            .hasMessageContaining("999");
    }

    @Test
    @DisplayName("should publish event after successful creation")
    void shouldPublishEventAfterCreation() {
        // Arrange
        <Resource>Request request = new <Resource>Request("test@example.com", ResourceType.STANDARD);
        <Resource>Entity savedEntity = <Resource>Entity.builder().id(1L).email("test@example.com").build();
        when(<resource>Repository.save(any())).thenReturn(savedEntity);

        // Act
        <resource>Service.create(request);

        // Assert
        verify(eventProducer).publish(any(<Event>Event.class));
    }
}
```

## Repository Test Template
```java
/**
 * Integration tests for {@link <Resource>Repository}.
 * Uses H2 in-memory DB (or Testcontainers for MySQL/Postgres).
 */
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Testcontainers
class <Resource>RepositoryTest {

    @Container
    static MySQLContainer<?> mysql = new MySQLContainer<>("mysql:8.0")
        .withDatabaseName("testdb")
        .withUsername("test")
        .withPassword("test");

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", mysql::getJdbcUrl);
        registry.add("spring.datasource.username", mysql::getUsername);
        registry.add("spring.datasource.password", mysql::getPassword);
    }

    @Autowired
    private <Resource>Repository repository;

    @Test
    @DisplayName("should find <resource> by email and active status")
    void shouldFind<Resource>ByEmailAndActive() {
        // Arrange
        <Resource>Entity entity = <Resource>Entity.builder()
            .email("test@example.com").status(Status.ACTIVE).build();
        repository.save(entity);

        // Act
        Optional<<Resource>Entity> result = repository.findByEmailAndActive("test@example.com", true);

        // Assert
        assertThat(result).isPresent();
        assertThat(result.get().getEmail()).isEqualTo("test@example.com");
    }
}
```

## Coverage Report Check
After tests are generated, verify with:
```bash
mvn test jacoco:report
# Check target/site/jacoco/index.html
# Fail if line coverage < 85%
```

## Acceptance Criteria Coverage Matrix
For every AC in requirement.md, generate a mapping:
```
AC1: "User receives OTP email" → shouldSendOtpEmailWhenValidEmailProvided ✓
AC2: "OTP expires after 5 minutes" → shouldThrowOtpExpiredExceptionAfter5Minutes ✓
AC3: "Max 5 OTP attempts per hour" → shouldBlockAfter5FailedAttemptsWithinOneHour ✓
```
