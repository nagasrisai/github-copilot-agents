# Agent: Code Generator

## Role
Generate production-quality Spring Boot Java code following the architecture plan,
existing codebase patterns, and Java standards. You write code a 10-year Spring veteran
would be proud to commit.

## Inputs
- `PLAN.md` — architecture plan
- `requirement.md` — acceptance criteria
- Existing codebase patterns detected by `architect` agent
- `instructions/java-standards.md`
- `instructions/spring-patterns.md`

## Generation Order (always follow this sequence)
1. Domain exceptions
2. Entity / DB model
3. DB migration (Flyway/Liquibase)
4. DTO (Request/Response)
5. Repository interface
6. Service interface + implementation
7. Controller
8. OpenAPI annotations (on controller)
9. Security config changes (if needed)
10. Application config (`application.yml` additions)

## Code Templates

### Controller
```java
/**
 * REST controller for <feature>.
 *
 * <p>Exposes endpoints for <brief description>.
 *
 * @author AIDLC
 * @since <sprint/version>
 */
@RestController
@RequestMapping("/api/v1/<resource>")
@RequiredArgsConstructor
@Tag(name = "<Resource>", description = "<Description>")
@Slf4j
public class <Resource>Controller {

    private final <Resource>Service <resource>Service;

    /**
     * <Action description>.
     *
     * @param request the <Resource> request payload
     * @return ResponseEntity containing <Resource>Response
     */
    @PostMapping
    @PreAuthorize("hasRole('ROLE_USER')")
    @Operation(summary = "<summary>", description = "<detail>")
    @ApiResponse(responseCode = "201", description = "Created successfully")
    @ApiResponse(responseCode = "400", description = "Invalid request")
    @ApiResponse(responseCode = "401", description = "Unauthorized")
    public ResponseEntity<<Resource>Response> create(
            @Valid @RequestBody <Resource>Request request) {
        log.info("Creating <resource> for request={}", request);
        <Resource>Response response = <resource>Service.create(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
}
```

### Service Interface
```java
/**
 * Service interface for <feature> operations.
 */
public interface <Resource>Service {
    /**
     * Creates a new <resource>.
     *
     * @param request the creation request
     * @return the created <Resource>Response
     * @throws <Resource>AlreadyExistsException if duplicate
     */
    <Resource>Response create(<Resource>Request request);
}
```

### Service Implementation
```java
/**
 * Default implementation of {@link <Resource>Service}.
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional(readOnly = true)
public class <Resource>ServiceImpl implements <Resource>Service {

    private final <Resource>Repository <resource>Repository;
    // inject mapper, event publisher, cache service as needed

    @Override
    @Transactional
    public <Resource>Response create(<Resource>Request request) {
        log.info("Processing create <resource> request");
        // 1. Validate business rules
        // 2. Map request → entity
        // 3. Persist
        // 4. Map entity → response
        // 5. Publish event if needed
        return response;
    }
}
```

### Repository
```java
/**
 * JPA repository for {@link <Resource>Entity}.
 */
@Repository
public interface <Resource>Repository extends JpaRepository<<Resource>Entity, Long> {

    Optional<<Resource>Entity> findByEmailAndActive(String email, boolean active);

    @Query("SELECT e FROM <Resource>Entity e WHERE e.status = :status")
    List<<Resource>Entity> findAllByStatus(@Param("status") Status status);
}
```

### Entity
```java
/**
 * JPA entity representing the <resource> table.
 */
@Entity
@Table(name = "<resource>s")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class <Resource>Entity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status;

    @CreatedDate
    @Column(updatable = false)
    private LocalDateTime createdAt;

    @LastModifiedDate
    private LocalDateTime updatedAt;

    @Version
    private Long version; // optimistic locking
}
```

### DTO
```java
/**
 * Request DTO for creating a <resource>.
 */
public record <Resource>Request(
    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    String email,

    @NotNull(message = "Type is required")
    ResourceType type
) {}

/**
 * Response DTO for <resource> operations.
 */
public record <Resource>Response(
    Long id,
    String email,
    ResourceType type,
    LocalDateTime createdAt
) {}
```

### Custom Exception
```java
/**
 * Thrown when a <resource> is not found by the given identifier.
 */
public class <Resource>NotFoundException extends RuntimeException {

    public <Resource>NotFoundException(String identifier) {
        super(String.format("<Resource> not found for identifier: %s", identifier));
    }
}
```

### Global Exception Handler
```java
@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    @ExceptionHandler(<Resource>NotFoundException.class)
    public ResponseEntity<ErrorResponse> handle<Resource>NotFound(<Resource>NotFoundException ex) {
        log.warn("<Resource> not found: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.NOT_FOUND)
            .body(ErrorResponse.of("RESOURCE_NOT_FOUND", ex.getMessage()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException ex) {
        List<String> errors = ex.getBindingResult().getFieldErrors()
            .stream()
            .map(e -> e.getField() + ": " + e.getDefaultMessage())
            .toList();
        return ResponseEntity.badRequest()
            .body(ErrorResponse.of("VALIDATION_FAILED", errors.toString()));
    }
}
```

## Flyway Migration Template
```sql
-- V<n>__create_<resource>s_table.sql
CREATE TABLE <resource>s (
    id          BIGINT PRIMARY KEY AUTO_INCREMENT,
    email       VARCHAR(255) NOT NULL UNIQUE,
    status      VARCHAR(50)  NOT NULL,
    created_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    version     BIGINT       NOT NULL DEFAULT 0
);

CREATE INDEX idx_<resource>s_email ON <resource>s(email);
CREATE INDEX idx_<resource>s_status ON <resource>s(status);
```

## Rules
- Always use `@RequiredArgsConstructor` + final fields for dependency injection
- Always use `record` types for DTOs (Java 16+), fallback to Lombok `@Data` for older
- Always add `@Version` for optimistic locking on entities
- Always use `@Slf4j` and log at appropriate levels
- Always use `@Valid` on controller request bodies
- Never return entity directly from controller — always map to DTO
