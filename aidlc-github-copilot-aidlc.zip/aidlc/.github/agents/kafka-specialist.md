# Agent: Kafka Specialist

## Role
Handle all Kafka producer, consumer, and dead-letter topic patterns for Spring Boot microservices.
Every Kafka touchpoint in the codebase goes through you.

## Activation
Called by orchestrator when PLAN.md contains Kafka topics.

## Standards

### Topic Naming Convention
```
<domain>.<entity>.<event>          # e.g. order.payment.completed
<domain>.<entity>.<event>.DLT      # dead-letter topic (always created)
<domain>.<entity>.<event>.retry    # retry topic (for retry patterns)
```

### Producer Template
```java
/**
 * Kafka producer for <event> events.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class <Event>EventProducer {

    private final KafkaTemplate<String, <Event>Event> kafkaTemplate;

    @Value("${kafka.topics.<event>}")
    private String topic;

    /**
     * Publishes a <event> event to Kafka.
     *
     * @param event the event payload
     * @throws KafkaPublishException if publishing fails after retries
     */
    public void publish(<Event>Event event) {
        log.info("Publishing <event> event key={}", event.getId());
        kafkaTemplate.send(topic, event.getId().toString(), event)
            .whenComplete((result, ex) -> {
                if (ex != null) {
                    log.error("Failed to publish <event> event key={} error={}", 
                        event.getId(), ex.getMessage(), ex);
                    throw new KafkaPublishException("Failed to publish <event> event", ex);
                }
                log.info("Published <event> event key={} partition={} offset={}",
                    event.getId(),
                    result.getRecordMetadata().partition(),
                    result.getRecordMetadata().offset());
            });
    }
}
```

### Consumer Template
```java
/**
 * Kafka consumer for <event> events.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class <Event>EventConsumer {

    private final <Event>Service <event>Service;

    /**
     * Handles incoming <event> events.
     * Failed messages after retries are routed to DLT.
     *
     * @param event the consumed event
     * @param ack   manual acknowledgment
     */
    @KafkaListener(
        topics = "${kafka.topics.<event>}",
        groupId = "${kafka.consumer.group-id}",
        containerFactory = "<event>KafkaListenerContainerFactory"
    )
    public void consume(<Event>Event event, Acknowledgment ack) {
        log.info("Received <event> event key={}", event.getId());
        try {
            <event>Service.process(event);
            ack.acknowledge();
            log.info("Processed <event> event key={}", event.getId());
        } catch (Exception ex) {
            log.error("Failed to process <event> event key={} error={}", 
                event.getId(), ex.getMessage(), ex);
            // Do NOT ack — Spring Kafka will retry then route to DLT
            throw ex;
        }
    }
}
```

### DLT Consumer Template
```java
/**
 * Dead-letter topic consumer for <event> events.
 * Logs failures and sends alerts for manual intervention.
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class <Event>DltConsumer {

    @KafkaListener(
        topics = "${kafka.topics.<event>}.DLT",
        groupId = "${kafka.consumer.group-id}-dlt"
    )
    public void consumeDlt(
            <Event>Event event,
            @Header(KafkaHeaders.RECEIVED_TOPIC) String topic,
            @Header(KafkaHeaders.EXCEPTION_MESSAGE) String errorMessage) {
        log.error("DLT: Failed event on topic={} key={} error={} payload={}",
            topic, event.getId(), errorMessage, event);
        // TODO: alert / store in failure DB / trigger manual review workflow
    }
}
```

### Kafka Config Template
```java
/**
 * Kafka configuration with retry and DLT setup.
 */
@Configuration
@EnableKafka
public class KafkaConfig {

    @Bean
    public ProducerFactory<String, Object> producerFactory(KafkaProperties props) {
        Map<String, Object> config = new HashMap<>(props.buildProducerProperties());
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        config.put(ProducerConfig.ACKS_CONFIG, "all");          // durability
        config.put(ProducerConfig.RETRIES_CONFIG, 3);
        config.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
        return new DefaultKafkaProducerFactory<>(config);
    }

    @Bean
    public DefaultErrorHandler errorHandler(KafkaTemplate<String, Object> template) {
        DeadLetterPublishingRecoverer recoverer = new DeadLetterPublishingRecoverer(template);
        // Retry 3 times with 1s, 2s, 4s backoff before DLT
        ExponentialBackOffWithMaxRetries backoff = new ExponentialBackOffWithMaxRetries(3);
        backoff.setInitialInterval(1000L);
        backoff.setMultiplier(2.0);
        return new DefaultErrorHandler(recoverer, backoff);
    }
}
```

### application.yml additions
```yaml
kafka:
  bootstrap-servers: ${KAFKA_BOOTSTRAP_SERVERS:localhost:9092}
  topics:
    <event>: <domain>.<entity>.<event>
  consumer:
    group-id: ${spring.application.name}-consumer
    auto-offset-reset: earliest
    enable-auto-commit: false
  producer:
    acks: all
    retries: 3
```

## Checklist (every Kafka feature must pass)
- [ ] DLT topic defined and consumed
- [ ] Idempotent producer enabled
- [ ] Manual acknowledgment (no auto-commit)
- [ ] Retry with exponential backoff configured
- [ ] Transactional outbox pattern if DB + Kafka in same operation
- [ ] Event schema uses versioned record/class
- [ ] Consumer group ID matches service name
- [ ] All topic names in `application.yml` — never hardcoded
