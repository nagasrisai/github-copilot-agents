# AIDLC — AI-Driven Development Lifecycle
### For Java Spring Boot Microservices Teams

> Drop this `.github/` folder into any Java/Spring microservice repo.  
> Give it a Jira ticket or a plain English requirement — it handles everything else.

---

## What It Does

AIDLC automates the full development lifecycle for Java Spring Boot microservices:

```
Input (Jira ticket / prompt / nightly schedule)
  │
  ▼
[Jira Analyzer]       Parse requirement → structured spec
  │
  ▼
[Architect]           Design plan: classes, APIs, Kafka topics, Redis keys, DB migration
  │
  ▼
[Code Generator]      Spring Boot code: Controller → Service → Repository → Entity → DTO
  │
  ├── [Kafka Specialist]     Producers, consumers, DLT, retry config
  ├── [Redis Specialist]     Caching, rate limiting, distributed locks
  └── [Security Specialist]  OAuth2, JWT converter, @PreAuthorize
  │
  ▼
[Test Generator]      JUnit 5 + Mockito unit tests (90% coverage target)
[E2E Test Generator]  Testcontainers + RestAssured integration tests
  │
  ▼
[Doc Generator]       OpenAPI annotations, Javadoc, CHANGELOG, ADR, PR body
  │
  ▼
[Java Standards]      Enforce naming, structure, exception handling, logging (auto-fix loop)
  │
  ▼
[Senior Reviewer]     10-year Java veteran persona — correctness, edge cases, N+1, pagination
  │
  ▼
[Architect Reviewer]  Principal Architect — boundaries, scalability, resilience, security posture
  │
  ▼ ← Human Checkpoint C4: "Approve push and PR? [y/N]"
  │
[Push + PR]           Branch, commit, push, GitHub PR with full description
  │
  ▼
[CI Monitor]          Jenkins (poll every 30s) → diagnose failures → auto-fix → re-trigger
  ├── [SonarQube]     Quality gate → fix Blocker/Critical issues → re-generate coverage tests
  └── [Nexus IQ]      CVE scan → auto-bump dependencies → report unresolvable CVEs
  │
  ▼
[Final Report]        CI status posted to GitHub PR comment
```

---

## Human Checkpoints (5 total — default NO, pipeline always stops safely)

| Checkpoint | Stage | Question |
|-----------|-------|----------|
| **C1** | After requirement parsed | "Understood. Proceed with pipeline?" |
| **C2** | Before branch created | "Create branch `feature/PROJ-123-...`?" |
| **C3** | After architect plan | "Plan ready. Proceed to code generation?" |
| **C4** | After all reviews pass | "All reviews passed. Push and open PR?" |
| **C5** | Jenkins build failed | "Auto-fix applied. Re-trigger build?" |

---

## Agents (17 total — 4 pipelines)

| Agent | Pipeline | Role |
|-------|----------|------|
| `orchestrator` | All | Pipeline coordinator, routing, run state, checkpoint enforcement |
| `jira-analyzer` | All | Parses Jira tickets, prompts, or interactive input → requirement.md |
| `architect` | Feature | Designs classes, API contracts, Kafka/Redis/DB schema, ADR |
| `java-standards` | All | Enforces team Java standards, auto-fix loop |
| `code-generator` | Feature | Spring Boot source: Controller/Service/Repository/Entity/DTO/Exceptions |
| `kafka-specialist` | Feature | Producers, consumers, DLT, idempotent config, retry |
| `redis-specialist` | Feature | Caching, rate limiting, distributed locks, TTL enforcement |
| `security-specialist` | Feature | OAuth2, JWT converter, `@PreAuthorize`, security config |
| `test-generator` | Feature | JUnit 5 + Mockito unit tests, 90% coverage, all ACs covered |
| `e2e-test-generator` | Feature + Upgrade | Testcontainers + RestAssured full-stack E2E tests |
| `doc-generator` | All | OpenAPI annotations, Javadoc, CHANGELOG, ADR, PR body |
| `senior-reviewer` | All | Senior Engineer persona — peer code review (max 3 iterations) |
| `architect-reviewer` | Feature + Bug (Critical) | Principal Architect persona — system design review |
| `ci-monitor` | All | Jenkins/SonarQube/Nexus IQ monitoring, diagnosis, auto-fix loop |
| `bugfix-workflow` | Bug Fix | Reproduce → root cause → impact map → fix → regression test |
| `refactoring` | Refactor | Extract service/controller, rename, move, decompose — zero behavior change |
| `upgrade-agent` | Upgrade | Java + Spring Boot upgrade — OpenRewrite, fix loops, Sonar + Nexus + Jenkins until GREEN |

---

## Quick Start

### 1. Prerequisites
```bash
node >= 18
npm >= 9
git
gh (GitHub CLI with Copilot extension)
Java 8/11/17/21 (auto-detected)
Maven or Gradle (auto-detected)
```

### 2. Set Environment Variables
```bash
# Copy the template
cp .github/.env.example .env

# Fill in your values
export JIRA_BASE_URL=https://yourcompany.atlassian.net
export JIRA_API_TOKEN=your-jira-token
export JIRA_EMAIL=yourname@company.com
export JIRA_PROJECT_KEY=PROJ

export JENKINS_URL=https://jenkins.yourcompany.com
export JENKINS_USER=your-jenkins-user
export JENKINS_TOKEN=your-jenkins-token

export SONAR_URL=https://sonar.yourcompany.com
export SONAR_TOKEN=your-sonar-token
export SONAR_PROJECT_KEY=com.company:your-service

export NEXUS_IQ_URL=https://nexus-iq.yourcompany.com
export NEXUS_IQ_USER=your-nexus-user
export NEXUS_IQ_PASSWORD=your-nexus-password
export NEXUS_APP_ID=your-app-id

export GITHUB_TOKEN=your-github-pat
```

For CI (GitHub Actions), add all the above as **GitHub Repository Secrets**.

### 3. Install MCP Servers
```bash
.github/scripts/setup-mcp-servers.sh
```

This installs MCP servers for Jira, Jenkins, SonarQube, Nexus IQ, and GitHub,
and writes `.vscode/mcp.json` for Copilot Chat to connect.

### 4. Bootstrap
```bash
.github/scripts/aidlc.sh bootstrap
```

### 5. Run the Pipeline

**From a Jira ticket:**
```bash
.github/scripts/aidlc.sh start --ticket PROJ-123
```

**From a free-text prompt:**
```bash
.github/scripts/aidlc.sh start --prompt "Add OTP-based two-factor authentication to the login flow"
```

**Interactive:**
```bash
.github/scripts/aidlc.sh start
```

**Resume an interrupted run:**
```bash
.github/scripts/aidlc.sh resume run-2026-05-16-001
```

---

## Manual Pipeline Trigger (GitHub Actions)
The workflow `.github/workflows/aidlc-pipeline.yml` is triggered manually from GitHub Actions UI.

Go to: **GitHub → Actions → AIDLC Pipeline → Run workflow**

Inputs:
- `ticket_key` — e.g. `PROJ-123`
- `prompt` — e.g. `"add OTP-based two-factor authentication"`

One of the two must be provided. If neither is given, the workflow exits with an error.

---

## Stack Support

| Java | Spring Boot | Supported | Notes |
|------|-------------|-----------|-------|
| 21 | 3.2+ | ✅ Full | Records, virtual threads |
| 17 | 3.0–3.2 | ✅ Full | Records, modern APIs |
| 11 | 2.7.x | ✅ Full | var, no records |
| 8  | 2.7.x | ✅ Legacy | Lombok DTOs, older patterns |

Stack is **auto-detected** from `pom.xml` / `build.gradle` — no config needed.

---

## Tech Stack Covered

| Feature | Tools |
|---------|-------|
| REST APIs | Spring MVC, OpenAPI 3 (SpringDoc) |
| Messaging | Kafka (producers, consumers, DLT, retry) |
| Caching | Redis (Spring Cache, rate limiter, distributed lock) |
| Security | OAuth2 Resource Server, JWT (Keycloak-compatible), `@PreAuthorize` |
| Persistence | JPA/Hibernate, Flyway migrations, optimistic locking |
| Testing | JUnit 5, Mockito, AssertJ, Testcontainers, RestAssured, Awaitility |
| Docs | OpenAPI 3, Javadoc, CHANGELOG, ADR |
| CI | Jenkins (monitor + auto-fix) |
| Quality | SonarQube (quality gate + auto-fix) |
| Security Scan | Nexus IQ (CVE auto-bump) |
| PRs | GitHub (auto PR with rich description) |

---

## File Structure

```
.github/
├── copilot-instructions.md          ← Global instructions (loaded every session)
│
├── agents/                          ← 14 specialized agents
│   ├── orchestrator.md
│   ├── jira-analyzer.md
│   ├── architect.md
│   ├── java-standards.md
│   ├── code-generator.md
│   ├── kafka-specialist.md
│   ├── redis-specialist.md
│   ├── security-specialist.md
│   ├── test-generator.md
│   ├── e2e-test-generator.md
│   ├── doc-generator.md
│   ├── senior-reviewer.md
│   ├── architect-reviewer.md
│   └── ci-monitor.md
│
├── instructions/                    ← Knowledge base (loaded by agents as needed)
│   ├── java-standards.md            ← Java coding standards with version matrix
│   ├── spring-patterns.md           ← Spring Boot patterns reference
│   ├── testing-standards.md         ← Testing patterns and conventions
│   ├── openapi-standards.md         ← OpenAPI annotation patterns
│   ├── mcp-wiring.md               ← MCP server config and env vars
│   ├── upgrade-playbook.md          ← Dependency upgrade rules
│   └── service-map.md              ← Jira component → microservice mapping (edit this)
│
├── prompts/                         ← Copilot prompt templates
│   ├── start-from-jira.prompt.md
│   ├── start-from-prompt.prompt.md
│   ├── senior-review.prompt.md
│   └── architect-review.prompt.md
│
├── scripts/
│   ├── aidlc.sh                     ← Main CLI entry point
│   ├── setup-mcp-servers.sh         ← One-time MCP server installation
│   └── ci-fix.sh                    ← CI failure diagnosis and fix
│
├── workflows/
│   ├── aidlc-nightly.yml            ← Scheduled nightly pipeline
│   └── aidlc-ci-monitor.yml         ← PR-triggered CI monitoring
│
└── skills/
    └── README.md                    ← Agent capabilities summary

.aidlc/                              ← Runtime state (not committed)
└── runs/
    └── run-2026-05-16-001/
        ├── state.json               ← Pipeline state
        ├── requirement.md           ← Parsed requirement
        ├── PLAN.md                  ← Architecture plan
        ├── senior-review.md         ← Senior review output
        ├── architect-review.md      ← Architect review output
        ├── standards-review.md      ← Java standards review output
        └── ci-fix-report.md         ← CI diagnosis and fix report
```

---

## Customization

### Add a new microservice to service-map.md
```yaml
services:
  your-new-service:
    repo: github.com/company/your-new-service
    jira_components: ["Your Component"]
    jira_labels: ["your-label"]
    domain: yourdomain
```

### Change review iteration limits
In `orchestrator.md`, update:
```markdown
- Loop: code-generator fixes → re-review (max 3 iterations)  ← Senior
- Loop: fix → re-review (max 2 iterations)                    ← Architect
```

### Change coverage threshold
In `test-generator.md`:
```markdown
Minimum 85% line coverage. Target 90%.
```

### Disable a stage
In `orchestrator.md`, comment out the stage in the Pipeline Stages section.

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| `gh copilot` not found | `gh extension install github/gh-copilot` |
| Jira MCP auth fails | Check `JIRA_API_TOKEN` and `JIRA_EMAIL` — use API token, not password |
| Jenkins poll times out | Increase `timeout-minutes` in `aidlc-nightly.yml` |
| SonarQube gate always fails | Check `SONAR_PROJECT_KEY` matches your project key exactly |
| Nexus IQ scan not found | Verify `NEXUS_APP_ID` matches the application ID in Nexus IQ |
| Run state corrupted | Delete `.aidlc/runs/<run-id>/` and start fresh |
| Copilot doesn't load agents | Ensure `.github/copilot-instructions.md` is in repo root's `.github/` folder |

---

## Contributing

1. Edit agent files in `.github/agents/` to refine behaviors
2. Update instruction files in `.github/instructions/` for new standards
3. Add new prompts in `.github/prompts/` for new pipeline entry points
4. Test changes by running `aidlc.sh start --prompt "test feature"` on a sandbox repo

---

*Built for Java Spring Boot microservice teams. Powered by GitHub Copilot + MCP.*
