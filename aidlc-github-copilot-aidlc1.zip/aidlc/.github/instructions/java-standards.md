# Java Coding Standards — Team Reference

## Version Support Matrix
| Java | Spring Boot | Notes |
|------|-------------|-------|
| 8    | 2.7.x       | Legacy — no records, no var in lambdas |
| 11   | 2.7.x       | var available, no records |
| 17   | 3.0–3.2     | Records, sealed classes, text blocks |
| 21   | 3.2+        | Virtual threads, pattern matching switch |

## Naming Conventions

### Classes
```java
// Services
UserService, UserServiceImpl, OrderProcessingService
// Controllers
UserController, OrderController
// Repositories
UserRepository
// Entities
UserEntity (or just User if by-domain structure)
// DTOs
CreateUserRequest, UserResponse, UpdateUserRequest
// Events
UserCreatedEvent, OrderProcessedEvent
// Exceptions
UserNotFoundException, OrderAlreadyExistsException, InvalidOtpException
// Config
SecurityConfig, RedisConfig, KafkaConfig, OpenApiConfig
// Utils (minimize — prefer domain objects)
DateUtils, StringUtils
```

### Methods
```java
// Queries
findById, findAllByStatus, existsByEmail
// Commands
create, update, delete, process, publish, send
// Booleans
isActive, hasPermission, canProceed, shouldRetry
// Transformers
toResponse, toEntity, toEvent
// Validators
validateRequest, validate<Domain>
```

### Constants
```java
public static final int MAX_RETRY_ATTEMPTS = 3;
public static final String DEFAULT_ROLE = "ROLE_USER";
public static final Duration OTP_TTL = Duration.ofMinutes(5);
```

## Package Structure

### By Layer (smaller services)
```
com.company.servicename
├── config/          # Spring configs
├── controller/      # REST controllers
├── service/         # Service interfaces + impls
├── repository/      # JPA repositories
├── entity/          # JPA entities
├── dto/             # Request/Response records
├── event/           # Kafka event classes
├── exception/       # Domain exceptions
├── security/        # Security config, JWT
└── util/            # Utilities (minimal)
```

### By Feature (larger services)
```
com.company.servicename
├── config/
├── shared/exception, dto, util
├── user/
│   ├── UserController.java
│   ├── UserService.java
│   ├── UserServiceImpl.java
│   ├── UserRepository.java
│   ├── UserEntity.java
│   ├── UserRequest.java
│   └── UserResponse.java
└── order/
    └── ...
```

## Dependency Injection
```java
// ✅ CORRECT — constructor injection
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final EventPublisher eventPublisher;
}

// ❌ WRONG — field injection
@Service
public class UserServiceImpl {
    @Autowired
    private UserRepository userRepository;
}
```

## Exception Strategy
```java
// Custom exception hierarchy
public class DomainException extends RuntimeException { ... }
public class UserNotFoundException extends DomainException { ... }
public class UserAlreadyExistsException extends DomainException { ... }
public class InvalidOtpException extends DomainException { ... }

// Global handler maps to HTTP
@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<ErrorResponse> handle(...) { ... } // → 404

    @ExceptionHandler(UserAlreadyExistsException.class)
    public ResponseEntity<ErrorResponse> handle(...) { ... } // → 409
}
```

## Null Safety
```java
// ✅ Use Optional from repository
Optional<UserEntity> user = userRepository.findById(id);
user.orElseThrow(() -> new UserNotFoundException(id.toString()));

// ✅ Use Objects.requireNonNull in constructors of value objects
public UserResponse(Long id, String email) {
    this.id = Objects.requireNonNull(id, "id must not be null");
    this.email = Objects.requireNonNull(email, "email must not be null");
}

// ❌ Never return null from a service method — return Optional or throw
```

## Java Version Idioms

### Java 17+ (Spring Boot 3.x)
```java
// Records for DTOs
public record CreateUserRequest(
    @NotBlank String email,
    @NotNull UserType type
) {}

// Text blocks for SQL / JSON in tests
String json = """
    {
        "email": "test@example.com",
        "type": "STANDARD"
    }
    """;

// Pattern matching instanceof
if (exception instanceof UserNotFoundException notFound) {
    log.warn("User not found: {}", notFound.getUserId());
}

// Switch expressions
String description = switch (status) {
    case ACTIVE -> "Active user";
    case SUSPENDED -> "Suspended account";
    case DELETED -> "Deleted account";
};
```

### Java 11 (Spring Boot 2.x)
```java
// var for local variables (improves readability)
var users = userRepository.findAllByStatus(Status.ACTIVE);

// No records — use Lombok @Data @Builder
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class CreateUserRequest {
    @NotBlank private String email;
    @NotNull private UserType type;
}
```

### Java 8 (Legacy)
```java
// Streams are fine
List<UserResponse> responses = users.stream()
    .map(this::toResponse)
    .collect(Collectors.toList()); // No .toList() shorthand in Java 8

// No var, no records — explicit types
```

## Logging Standards
```java
@Slf4j
public class UserServiceImpl {
    public UserResponse create(CreateUserRequest request) {
        log.info("Creating user email={}", request.email()); // INFO: business event
        try {
            UserEntity saved = userRepository.save(toEntity(request));
            log.info("Created user userId={}", saved.getId()); // INFO: success
            return toResponse(saved);
        } catch (DataIntegrityViolationException ex) {
            log.warn("Duplicate user email={}", request.email()); // WARN: expected failure
            throw new UserAlreadyExistsException(request.email());
        }
    }
}

// DEBUG: development detail (not visible in production by default)
log.debug("Executing query with params={}", params);

// ERROR: unexpected failure requiring attention
log.error("Failed to process user userId={} error={}", userId, ex.getMessage(), ex);
```
