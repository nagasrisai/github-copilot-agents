# Service Map & MCP Wiring

## Service Map
Map Jira components/labels to microservice repositories.
Update this file when new services are added.

```yaml
services:
  user-service:
    repo: github.com/company/user-service
    jira_components: ["User Management", "Auth"]
    jira_labels: ["user", "auth", "login"]
    domain: users

  order-service:
    repo: github.com/company/order-service
    jira_components: ["Orders", "Checkout"]
    jira_labels: ["order", "cart", "checkout"]
    domain: orders

  notification-service:
    repo: github.com/company/notification-service
    jira_components: ["Notifications", "Email", "SMS"]
    jira_labels: ["notification", "email", "sms"]
    domain: notifications

  # Add more services here
```

## MCP Server Configuration

### Jira MCP
```yaml
jira_mcp:
  server: jira-mcp-server
  config:
    base_url: ${JIRA_BASE_URL}      # e.g. https://company.atlassian.net
    api_token: ${JIRA_API_TOKEN}
    email: ${JIRA_EMAIL}
    project_key: ${JIRA_PROJECT_KEY}

tools_available:
  - jira_get_issue(issue_key)
  - jira_update_issue(issue_key, fields)
  - jira_add_comment(issue_key, comment)
  - jira_search_issues(jql)
  - jira_create_issue(project, summary, description, type, labels)
  - jira_transition_issue(issue_key, transition_name)

usage_in_pipeline:
  intake: jira_get_issue — fetch ticket details
  nightly: jira_search_issues — "project = PROJ AND status = 'In Progress' AND assignee = 'copilot-bot'"
  start: jira_transition_issue — move to "In Development"
  pr_created: jira_add_comment — add PR link
  done: jira_transition_issue — move to "In Review" or "Done"
```

### Jenkins MCP
```yaml
jenkins_mcp:
  server: jenkins-mcp-server
  config:
    base_url: ${JENKINS_URL}         # e.g. https://jenkins.company.com
    username: ${JENKINS_USER}
    token: ${JENKINS_TOKEN}

tools_available:
  - jenkins_get_build_status(job, build_number)
  - jenkins_get_console_log(job, build_number)
  - jenkins_trigger_build(job, parameters)
  - jenkins_get_latest_build(job)
  - jenkins_list_jobs()

usage_in_pipeline:
  ci_monitor: poll jenkins_get_build_status every 30s
  on_failure: jenkins_get_console_log → diagnose
  after_fix: jenkins_trigger_build
```

### SonarQube MCP
```yaml
sonarqube_mcp:
  server: sonarqube-mcp-server
  config:
    base_url: ${SONAR_URL}           # e.g. https://sonar.company.com
    token: ${SONAR_TOKEN}
    project_key: ${SONAR_PROJECT_KEY}

tools_available:
  - sonar_get_quality_gate_status(project_key)
  - sonar_get_issues(project_key, severities, types)
  - sonar_get_coverage(project_key)
  - sonar_get_uncovered_lines(project_key, file)
  - sonar_get_duplications(project_key)

usage_in_pipeline:
  after_jenkins_success: sonar_get_quality_gate_status
  on_failure: sonar_get_issues(severities=["BLOCKER","CRITICAL"])
  coverage_fix: sonar_get_uncovered_lines → test-generator
```

### Nexus IQ MCP
```yaml
nexus_iq_mcp:
  server: nexus-iq-mcp-server
  config:
    base_url: ${NEXUS_IQ_URL}        # e.g. https://nexus-iq.company.com
    username: ${NEXUS_IQ_USER}
    password: ${NEXUS_IQ_PASSWORD}
    app_id: ${NEXUS_APP_ID}

tools_available:
  - nexus_get_scan_report(app_id, stage)
  - nexus_get_violations(app_id, severity)
  - nexus_get_remediation_advice(violation_id)
  - nexus_get_component_info(group_id, artifact_id, version)

usage_in_pipeline:
  after_sonar_pass: nexus_get_scan_report
  on_failure: nexus_get_violations → auto-bump or flag
```

### GitHub MCP (gh CLI)
```yaml
github_mcp:
  tool: gh CLI (built-in)
  config:
    token: ${GITHUB_TOKEN}

commands_used:
  push: git push origin <branch>
  create_pr: gh pr create --title "..." --body "..." --base main
  add_comment: gh pr comment <pr_number> --body "..."
  get_pr_status: gh pr status
  merge: gh pr merge <pr_number> --squash (only on explicit human instruction)
```

## Environment Variables Required
```bash
# Jira
JIRA_BASE_URL=https://company.atlassian.net
JIRA_API_TOKEN=<from Atlassian account settings>
JIRA_EMAIL=copilot-bot@company.com
JIRA_PROJECT_KEY=PROJ

# Jenkins
JENKINS_URL=https://jenkins.company.com
JENKINS_USER=copilot-bot
JENKINS_TOKEN=<from Jenkins user settings>

# SonarQube
SONAR_URL=https://sonar.company.com
SONAR_TOKEN=<from SonarQube user settings>
SONAR_PROJECT_KEY=com.company:service-name

# Nexus IQ
NEXUS_IQ_URL=https://nexus-iq.company.com
NEXUS_IQ_USER=copilot-bot
NEXUS_IQ_PASSWORD=<from Nexus IQ>
NEXUS_APP_ID=<application ID in Nexus IQ>

# GitHub
GITHUB_TOKEN=<GitHub PAT with repo scope>
```

Store all secrets in GitHub Secrets or your secrets manager. Never in code or config files.
