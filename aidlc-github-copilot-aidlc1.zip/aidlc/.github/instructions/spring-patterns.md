# Spring Boot Patterns — Team Reference

## Controller Patterns

### Response Status Semantics
```java
// POST create → 201 Created
return ResponseEntity.status(HttpStatus.CREATED).body(response);

// GET → 200 OK (default)
return ResponseEntity.ok(response);

// PUT/PATCH update → 200 OK with updated resource
return ResponseEntity.ok(updated);

// DELETE → 204 No Content
return ResponseEntity.noContent().build();

// Async accepted → 202 Accepted
return ResponseEntity.accepted().build();
```

### Pagination on List Endpoints (mandatory for any list)
```java
@GetMapping
public ResponseEntity<Page<UserResponse>> findAll(
        @RequestParam(defaultValue = "0") int page,
        @RequestParam(defaultValue = "20") int size,
        @RequestParam(defaultValue = "createdAt") String sortBy,
        @RequestParam(defaultValue = "DESC") String direction) {
    Pageable pageable = PageRequest.of(page, size,
        Sort.by(Sort.Direction.valueOf(direction), sortBy));
    return ResponseEntity.ok(userService.findAll(pageable));
}
```

## Service Patterns

### Transactional Boundaries
```java
@Service
@Transactional(readOnly = true) // default for reads
public class UserServiceImpl implements UserService {

    @Override
    @Transactional // override for writes
    public UserResponse create(CreateUserRequest request) { ... }

    @Override
    // readOnly = true inherited
    public UserResponse findById(Long id) { ... }

    @Override
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void auditLog(AuditEvent event) { ... } // always own transaction
}
```

### Optimistic Locking
```java
// Entity
@Version
private Long version;

// Service — handle conflict
@Transactional
public UserResponse update(Long id, UpdateUserRequest request) {
    try {
        UserEntity user = userRepository.findById(id).orElseThrow(...);
        // ... update fields
        return toResponse(userRepository.save(user));
    } catch (OptimisticLockingFailureException ex) {
        log.warn("Concurrent update conflict for userId={}", id);
        throw new ConcurrentUpdateException("User was modified concurrently, please retry");
    }
}
```

## Repository Patterns

### Avoid N+1 with EntityGraph
```java
@Repository
public interface UserRepository extends JpaRepository<UserEntity, Long> {

    // Fetch user with roles in one query (no N+1)
    @EntityGraph(attributePaths = {"roles", "address"})
    Optional<UserEntity> findWithRolesById(Long id);

    // Projection for lightweight read
    @Query("SELECT u.id as id, u.email as email FROM UserEntity u WHERE u.status = :status")
    List<UserProjection> findProjectedByStatus(@Param("status") Status status);
}

// Projection interface
public interface UserProjection {
    Long getId();
    String getEmail();
}
```

### Batch Operations
```java
// ❌ Never do this
users.forEach(u -> userRepository.save(u)); // N individual inserts

// ✅ Batch save
userRepository.saveAll(users); // single batch

// ✅ Batch delete
userRepository.deleteAllByIdInBatch(ids);
```

## Configuration Patterns

### Type-Safe Config
```java
@ConfigurationProperties(prefix = "app.otp")
@Validated
public record OtpProperties(
    @DurationUnit(ChronoUnit.MINUTES) Duration ttl,
    @Min(1) @Max(10) int maxAttempts,
    @NotBlank String senderEmail
) {}

// Usage
@Service
@RequiredArgsConstructor
public class OtpServiceImpl implements OtpService {
    private final OtpProperties otpProperties;
    // otpProperties.ttl(), otpProperties.maxAttempts()
}
```

### application.yml structure
```yaml
# Grouped by feature — never scattered
app:
  otp:
    ttl: 5m
    max-attempts: 5
    sender-email: noreply@company.com
  security:
    jwt:
      issuer-uri: ${OAUTH2_ISSUER_URI}

spring:
  datasource:
    url: ${DB_URL:jdbc:mysql://localhost:3306/appdb}
    username: ${DB_USER:root}
    password: ${DB_PASSWORD:}

  jpa:
    hibernate:
      ddl-auto: validate  # NEVER create-drop in production
    show-sql: false        # true only for local dev profile

  flyway:
    enabled: true
    locations: classpath:db/migration
```

## Profiles Strategy
```
application.yml         — shared defaults, all env vars
application-local.yml   — local dev overrides (never committed with secrets)
application-test.yml    — test config (H2 or Testcontainers)
application-prod.yml    — production overrides (minimal — use env vars)
```

## Actuator Config
```yaml
management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics,prometheus
  endpoint:
    health:
      show-details: when-authorized
  info:
    env:
      enabled: true

info:
  app:
    name: ${spring.application.name}
    version: @project.version@
```

## DTO Mapping

### MapStruct (preferred for complex mappings)
```java
@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.ERROR)
public interface UserMapper {
    UserResponse toResponse(UserEntity entity);
    UserEntity toEntity(CreateUserRequest request);

    @Mapping(target = "id", ignore = true)
    @Mapping(target = "createdAt", ignore = true)
    void updateEntity(UpdateUserRequest request, @MappingTarget UserEntity entity);
}
```

### Manual mapping (acceptable for simple cases)
```java
private UserResponse toResponse(UserEntity entity) {
    return new UserResponse(entity.getId(), entity.getEmail(), entity.getStatus(), entity.getCreatedAt());
}
```

## Resilience Patterns (Resilience4j)

### Circuit Breaker on External Calls
```java
@Service
@RequiredArgsConstructor
public class ExternalServiceClient {

    private final WebClient webClient;

    @CircuitBreaker(name = "externalService", fallbackMethod = "fallback")
    @Retry(name = "externalService")
    @TimeLimiter(name = "externalService")
    public CompletableFuture<ExternalResponse> callExternal(String id) {
        return webClient.get()
            .uri("/external/{id}", id)
            .retrieve()
            .bodyToMono(ExternalResponse.class)
            .toFuture();
    }

    private CompletableFuture<ExternalResponse> fallback(String id, Exception ex) {
        log.warn("Circuit breaker open for externalService id={}", id);
        return CompletableFuture.completedFuture(ExternalResponse.empty());
    }
}
```

### application.yml Resilience config
```yaml
resilience4j:
  circuitbreaker:
    instances:
      externalService:
        sliding-window-size: 10
        failure-rate-threshold: 50
        wait-duration-in-open-state: 30s
  retry:
    instances:
      externalService:
        max-attempts: 3
        wait-duration: 500ms
        exponential-backoff-multiplier: 2
  timelimiter:
    instances:
      externalService:
        timeout-duration: 3s
```
