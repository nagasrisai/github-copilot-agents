# OpenAPI & Documentation Patterns

## SpringDoc OpenAPI 3 Setup

### Maven dependency (Spring Boot 3.x)
```xml
<dependency>
  <groupId>org.springdoc</groupId>
  <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
  <version>2.5.0</version>
</dependency>
```

### Maven dependency (Spring Boot 2.x)
```xml
<dependency>
  <groupId>org.springdoc</groupId>
  <artifactId>springdoc-openapi-ui</artifactId>
  <version>1.8.0</version>
</dependency>
```

### application.yml config
```yaml
springdoc:
  api-docs:
    path: /v3/api-docs
  swagger-ui:
    path: /swagger-ui.html
    operations-sorter: method
    tags-sorter: alpha
    try-it-out-enabled: true
  show-actuator: false

# Disable Swagger in production
---
spring.config.activate.on-profile: prod
springdoc:
  api-docs:
    enabled: false
  swagger-ui:
    enabled: false
```

## Annotation Reference

### Class-level
```java
@Tag(name = "User Management", description = "Operations for creating, retrieving, and managing users")
@RestController
@RequestMapping("/api/v1/users")
public class UserController { }
```

### Method-level — full example
```java
@Operation(
    summary = "Create a new user",
    description = """
        Creates a user account with the provided email and type.
        Requires ROLE_ADMIN. On success, publishes a user.created Kafka event
        and sends a welcome email via the notification service.
        """,
    security = @SecurityRequirement(name = "bearerAuth")
)
@ApiResponses({
    @ApiResponse(
        responseCode = "201",
        description = "User created successfully",
        content = @Content(
            mediaType = "application/json",
            schema = @Schema(implementation = UserResponse.class)
        )
    ),
    @ApiResponse(
        responseCode = "400",
        description = "Invalid request — validation failed",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))
    ),
    @ApiResponse(responseCode = "401", description = "Missing or expired token"),
    @ApiResponse(responseCode = "403", description = "Insufficient role — requires ADMIN"),
    @ApiResponse(
        responseCode = "409",
        description = "User with this email already exists",
        content = @Content(schema = @Schema(implementation = ErrorResponse.class))
    )
})
@PostMapping
@PreAuthorize("hasRole('ROLE_ADMIN')")
public ResponseEntity<UserResponse> create(@Valid @RequestBody CreateUserRequest request) { }
```

### Schema annotations on DTOs
```java
@Schema(description = "Request payload for creating a new user")
public record CreateUserRequest(

    @Schema(description = "User's email address", example = "jane.doe@company.com", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotBlank @Email
    String email,

    @Schema(description = "Account type", example = "STANDARD", allowableValues = {"STANDARD", "PREMIUM", "ADMIN"})
    @NotNull
    UserType type
) {}

@Schema(description = "Standard error response")
public record ErrorResponse(
    @Schema(description = "Machine-readable error code", example = "USER_NOT_FOUND")
    String code,

    @Schema(description = "Human-readable error message", example = "User not found for id: 123")
    String message,

    @Schema(description = "ISO-8601 timestamp", example = "2026-05-16T10:30:00Z")
    String timestamp
) {
    public static ErrorResponse of(String code, String message) {
        return new ErrorResponse(code, message, Instant.now().toString());
    }
}
```

## Javadoc Standards

### Class Javadoc template
```java
/**
 * Service responsible for managing user lifecycle operations.
 *
 * <p>Handles creation, retrieval, update, and deactivation of user accounts.
 * All mutating operations publish domain events to Kafka and invalidate Redis cache entries.
 *
 * <p>Business rules enforced:
 * <ul>
 *   <li>Email must be unique across all user types</li>
 *   <li>PREMIUM users require admin approval before activation</li>
 *   <li>Deleted users cannot be reactivated — create new account</li>
 * </ul>
 *
 * @author AIDLC
 * @since Sprint 42
 * @see UserRepository
 * @see UserCreatedEvent
 */
```

### Method Javadoc template
```java
/**
 * Retrieves a user by ID, using Redis cache with 10-minute TTL.
 *
 * <p>On cache miss, queries the database and caches the result.
 * Returns the cached version on subsequent calls within the TTL window.
 *
 * @param id the unique user identifier
 * @return the user response DTO
 * @throws UserNotFoundException if no user exists with the given ID
 * @throws IllegalArgumentException if id is null or negative
 */
```

## CHANGELOG Format
```markdown
# Changelog
All notable changes to this project will be documented in this file.
Format: Keep a Changelog (https://keepachangelog.com)

## [Unreleased]

### Added
- `POST /api/v1/users` — create user endpoint (PROJ-123)
- Redis caching for user lookups (TTL: 10 min)
- Kafka event `user.account.created` on user creation

### Changed
- `UserEntity` — added `userType` field with enum values

### Deprecated
- `GET /api/v1/users/search` — use `GET /api/v1/users?q=` instead (removal in v2.0)

### Security
- All `/api/v1/users/**` endpoints now require `ROLE_USER` minimum

### Fixed
- N/A

### Breaking Changes
- None

## [1.2.0] — 2026-04-10
...
```
