# Service Map
# Maps Jira components and labels to your microservice repositories.
# The jira-analyzer agent uses this to determine which service(s) a ticket affects.
# Update this file whenever you add a new microservice.

services:
  # ── Example services — replace with your own ──────────────

  user-service:
    repo: github.com/yourcompany/user-service
    jira_components: ["User Management", "Auth", "Profile"]
    jira_labels: ["user", "auth", "login", "otp", "2fa", "profile"]
    domain: users
    base_package: com.yourcompany.userservice
    default_branch: main

  order-service:
    repo: github.com/yourcompany/order-service
    jira_components: ["Orders", "Checkout", "Cart"]
    jira_labels: ["order", "cart", "checkout", "payment"]
    domain: orders
    base_package: com.yourcompany.orderservice
    default_branch: main

  notification-service:
    repo: github.com/yourcompany/notification-service
    jira_components: ["Notifications", "Email", "SMS", "Push"]
    jira_labels: ["notification", "email", "sms", "push"]
    domain: notifications
    base_package: com.yourcompany.notificationservice
    default_branch: main

  product-service:
    repo: github.com/yourcompany/product-service
    jira_components: ["Product Catalog", "Inventory", "Pricing"]
    jira_labels: ["product", "catalog", "inventory", "pricing"]
    domain: products
    base_package: com.yourcompany.productservice
    default_branch: main

  # ── Add your services below ───────────────────────────────

  # your-service-name:
  #   repo: github.com/yourcompany/your-service
  #   jira_components: ["Your Jira Component"]
  #   jira_labels: ["your-label", "another-label"]
  #   domain: yourdomain
  #   base_package: com.yourcompany.yourservice
  #   default_branch: main

# ── Multi-service rules ──────────────────────────────────
# When a ticket mentions components from multiple services:
# - List all affected services in requirement.md
# - Architect agent will flag if the scope crosses more than 2 services
# - Architect reviewer will evaluate coupling and boundaries
multi_service_threshold: 2   # flag if > 2 services affected
