# Dependency Upgrade Playbook

## When to Upgrade
1. Nexus IQ reports a CVE on a dependency
2. Spring Boot EOL warning
3. Scheduled quarterly dependency review
4. ci-monitor auto-bump triggered by CRITICAL/HIGH CVE

## Safe Upgrade Order (always follow this sequence)

### Step 1 — Identify affected dependency
```bash
# Maven
mvn dependency:tree | grep <artifact-id>

# Gradle
./gradlew dependencies | grep <artifact-id>
```

### Step 2 — Check compatibility matrix
Before bumping Spring Boot, verify:
- https://spring.io/projects/spring-boot#support (EOL dates)
- https://docs.spring.io/spring-boot/appendix/dependency-versions/index.html

| Spring Boot | Java Min | Java Max | Hibernate | Notes |
|-------------|----------|----------|-----------|-------|
| 2.7.x       | 8        | 19       | 5.6.x     | EOL Nov 2023 — migrate to 3.x |
| 3.0.x       | 17       | 19       | 6.1.x     | EOL Nov 2023 |
| 3.1.x       | 17       | 21       | 6.2.x     | EOL Nov 2024 |
| 3.2.x       | 17       | 21       | 6.4.x     | Supported |
| 3.3.x       | 17       | 21+      | 6.5.x     | Supported |

### Step 3 — Apply bump

#### Maven — single dependency
```xml
<!-- In pom.xml properties section -->
<properties>
  <spring-security.version>6.2.5</spring-security.version>
  <jackson.version>2.17.1</jackson.version>
</properties>
```

#### Maven — Spring Boot parent bump
```xml
<parent>
  <groupId>org.springframework.boot</groupId>
  <artifactId>spring-boot-starter-parent</artifactId>
  <version>3.2.5</version>  <!-- bump here -->
</parent>
```

#### Gradle
```groovy
// gradle.properties
springBootVersion=3.2.5
springSecurityVersion=6.2.5
```

### Step 4 — Verify no transitive conflict
```bash
# Maven
mvn dependency:tree -Dincludes=<group>:<artifact>
mvn validate

# Gradle
./gradlew dependencies --configuration compileClasspath
```

### Step 5 — Run full test suite locally
```bash
# Maven
mvn clean test

# Gradle
./gradlew clean test
```

### Step 6 — Check for Spring Boot migration issues

#### 2.x → 3.x common breaking changes
| Change | Old | New |
|--------|-----|-----|
| javax → jakarta namespace | `import javax.persistence.*` | `import jakarta.persistence.*` |
| Spring Security DSL | `http.authorizeRequests()` | `http.authorizeHttpRequests()` |
| spring.redis.* | `spring.redis.host` | `spring.data.redis.host` |
| spring.jpa.open-in-view | was true by default | now false — fix lazy loading |
| Actuator endpoint | `/actuator/health` | same, but details policy changed |
| @SpringBootTest location | any package | must be in/below main class package |

#### Automated migration helper (Spring Boot 3.x)
```bash
# OpenRewrite recipe for Spring Boot 3 migration
mvn -U org.openrewrite.maven:rewrite-maven-plugin:run \
  -Drewrite.recipeArtifactCoordinates=org.openrewrite.recipe:rewrite-spring:LATEST \
  -Drewrite.activeRecipes=org.openrewrite.java.spring.boot3.UpgradeSpringBoot_3_2
```

### Step 7 — Commit with CVE reference
```
fix(deps): upgrade spring-security 6.1.0 → 6.2.5 (CVE-2024-22257)
fix(deps): upgrade Spring Boot 3.1.12 → 3.2.5 (quarterly upgrade)
```

## CVE Triage Matrix
| CVSS Score | Severity | Action | Timeline |
|-----------|----------|--------|----------|
| 9.0–10.0  | Critical | Auto-bump + immediate PR | Same day |
| 7.0–8.9   | High     | Auto-bump + PR | Within 3 days |
| 4.0–6.9   | Medium   | Create ticket, schedule | Within sprint |
| 0.1–3.9   | Low      | Log only | Quarterly review |
| N/A        | License  | Escalate to human | Immediate |

## DO NOT Auto-Bump
These require human review before upgrading:
- Spring Boot major version (2.x → 3.x requires Java 17+, code migration)
- Hibernate major version (5.x → 6.x has breaking API changes)
- Kafka client major version (protocol compatibility)
- Any dependency flagged with license change (MIT → GPL etc.)
