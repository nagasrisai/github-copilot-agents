# Testing Standards — Team Reference

## Coverage Targets
| Layer | Tool | Minimum | Target |
|-------|------|---------|--------|
| Unit (controller) | @WebMvcTest | 85% | 90% |
| Unit (service) | @ExtendWith(MockitoExtension) | 85% | 90% |
| Unit (repository) | @DataJpaTest | 75% | 85% |
| Integration | Testcontainers | All endpoints | All flows |

## Test Class Organization
```java
// Naming
UserServiceImplTest.java       // matches production class name
UserControllerTest.java
UserRepositoryTest.java
UserApiE2ETest.java            // E2E suffix

// Structure within test class
@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    // 1. Mocks and InjectMocks
    @Mock private UserRepository userRepository;
    @InjectMocks private UserServiceImpl userService;

    // 2. Constants / test data
    private static final String TEST_EMAIL = "test@example.com";
    private static final Long TEST_ID = 1L;

    // 3. Nested classes by method under test (recommended for large test classes)
    @Nested
    @DisplayName("create()")
    class Create {
        @Test
        @DisplayName("should return created user when valid request")
        void shouldReturnCreatedUserWhenValidRequest() { ... }

        @Test
        @DisplayName("should throw UserAlreadyExistsException when email taken")
        void shouldThrowWhenEmailAlreadyExists() { ... }
    }

    @Nested
    @DisplayName("findById()")
    class FindById { ... }
}
```

## Assertion Style (AssertJ — always preferred over JUnit assertions)
```java
// ✅ AssertJ
assertThat(result).isNotNull();
assertThat(result.getEmail()).isEqualTo("test@example.com");
assertThat(result.getStatus()).isEqualByComparingTo(Status.ACTIVE);
assertThat(list).hasSize(3).containsExactly(item1, item2, item3);
assertThatThrownBy(() -> service.findById(999L))
    .isInstanceOf(UserNotFoundException.class)
    .hasMessageContaining("999");

// ❌ JUnit assertions (avoid)
assertEquals("test@example.com", result.getEmail());
```

## Test Data Builders
Create a test data builder for every entity (in `src/test/java/.../builder/`):
```java
public class UserEntityBuilder {
    private Long id = 1L;
    private String email = "test@example.com";
    private Status status = Status.ACTIVE;

    public static UserEntityBuilder aUser() { return new UserEntityBuilder(); }
    public UserEntityBuilder withId(Long id) { this.id = id; return this; }
    public UserEntityBuilder withEmail(String email) { this.email = email; return this; }
    public UserEntityBuilder withStatus(Status status) { this.status = status; return this; }
    public UserEntity build() {
        return UserEntity.builder().id(id).email(email).status(status).build();
    }
}

// Usage in tests
UserEntity user = UserEntityBuilder.aUser().withEmail("other@email.com").build();
```

## Parameterized Tests (for boundary values)
```java
@ParameterizedTest
@ValueSource(strings = {"", " ", "not-an-email", "missing@", "@nodomain"})
@DisplayName("should return 400 for invalid email formats")
void shouldReturn400ForInvalidEmail(String invalidEmail) throws Exception {
    mockMvc.perform(post("/api/v1/users")
            .contentType(MediaType.APPLICATION_JSON)
            .content("""{"email": "%s"}""".formatted(invalidEmail)))
        .andExpect(status().isBadRequest());
}
```

## Async Testing (Awaitility — never Thread.sleep)
```java
// ✅ Awaitility
await().atMost(10, SECONDS)
       .pollInterval(500, MILLISECONDS)
       .untilAsserted(() -> {
           verify(eventProducer, times(1)).publish(any(UserCreatedEvent.class));
       });

// ❌ Thread.sleep
Thread.sleep(2000);
verify(eventProducer).publish(...);
```

## Test JWT Factory (for security tests)
```java
// src/test/java/.../security/TestJwtFactory.java
public class TestJwtFactory {
    private static final String SECRET = "test-secret-at-least-256-bits-long-for-hmac";

    public static String createToken(String username, List<String> roles) {
        return Jwts.builder()
            .subject(username)
            .claim("realm_access", Map.of("roles", roles))
            .issuedAt(new Date())
            .expiration(new Date(System.currentTimeMillis() + 3600_000))
            .signWith(Keys.hmacShaKeyFor(SECRET.getBytes()))
            .compact();
    }
}
```

## Common Mistakes to Avoid
```java
// ❌ Testing implementation, not behavior
verify(repository).findById(id); // testing that method was called, not what was returned
// ✅ Test the outcome
assertThat(result.getEmail()).isEqualTo(expected); // behavior test

// ❌ Brittle mock setup
when(repository.findAll()).thenReturn(List.of(entity1, entity2, entity3));
// ✅ Return only what the test needs
when(repository.findByStatus(Status.ACTIVE)).thenReturn(List.of(activeEntity));

// ❌ Not testing the unhappy path
// Most test suites only test happy path — always test exceptions and edge cases

// ❌ One big test for everything
void shouldCreateUserAndSendEmailAndPublishEvent() { ... }
// ✅ One concept per test
void shouldCreateUser() { ... }
void shouldSendEmailAfterCreation() { ... }
void shouldPublishEventAfterCreation() { ... }
```
