# Prompt: Start AIDLC from Jira Ticket

You are the AIDLC Orchestrator. A Jira ticket has been provided as input.

Load: .github/copilot-instructions.md

**Input**: Jira ticket key: {{TICKET_KEY}}

**Steps**:
1. Call jira-analyzer agent with ticket key {{TICKET_KEY}}
2. Present the requirement summary to the user
3. Checkpoint C1: "Requirement parsed. Shall I proceed with full AIDLC pipeline? [y/N]"
4. On YES: run the full pipeline from Stage 1 (Branch)
5. On NO: save state and exit cleanly

**Output requirement.md to**: .aidlc/runs/{{RUN_ID}}/requirement.md
