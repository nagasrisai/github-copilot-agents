# Skills Index

## orchestrator
Owns the full pipeline run state. Coordinates all agents. Enforces human checkpoints.
Detects repo stack (Java version, Spring version, build tool). Handles error recovery and resume.

## jira-analyzer
Parses Jira tickets (via MCP), free-text prompts, and interactive input into a structured
requirement document with acceptance criteria, scope, affected services, and ambiguities.

## architect
Scans existing codebase, detects patterns, and produces a detailed architecture plan (PLAN.md)
covering: new components by layer, API contracts, Kafka topics+DLTs, Redis keys+TTLs,
DB changes, security changes, and ADR for new decisions.

## java-standards
Enforces team Java coding standards. Auto-fixes minor issues. Blocks on naming violations,
missing Javadoc, unchecked exceptions, field injection, hardcoded values, no-security endpoints.
Loops with code-generator to resolve violations.

## code-generator
Generates production Spring Boot code: Controller, Service interface+impl, Repository, Entity,
DTO (records for Java 17+, Lombok for older), custom exceptions, GlobalExceptionHandler,
Flyway migrations. Follows exact patterns of the existing codebase.

## kafka-specialist
Generates Kafka producers, consumers, DLT consumers, and KafkaConfig with:
idempotent producer, manual ack, exponential backoff retry, dead-letter routing.
Enforces: DLT always defined, all topics in config (never hardcoded), transactional outbox.

## redis-specialist
Generates Redis caching (Spring Cache abstraction), rate limiters (sliding window), and
distributed locks. Enforces: explicit TTL always set, naming convention, null not cached,
connection pooling with Lettuce, all config from environment variables.

## security-specialist
Generates Spring Security config (OAuth2 Resource Server), JWT converter (Keycloak-compatible),
method security annotations (`@PreAuthorize`). Enforces: no secrets in code, all endpoints
explicitly mapped, stateless sessions, actuator restricted.

## test-generator
Generates JUnit 5 + Mockito unit tests: @WebMvcTest for controllers, @ExtendWith(MockitoExtension)
for services, @DataJpaTest for repositories. Targets 90% coverage. Maps every AC to at least
one test. Uses AssertJ, TestBuilder pattern, @ParameterizedTest for boundary values.

## e2e-test-generator
Generates Testcontainers + RestAssured E2E tests. Full Spring context. Real MySQL/Postgres,
Redis, Kafka containers. Covers: all HTTP status codes per endpoint, full CRUD flows,
Kafka event verification with Awaitility, security (401/403 tests).

## doc-generator
Generates: OpenAPI annotations (full @Operation/@ApiResponse), Javadoc (class + public methods),
CHANGELOG entries, ADR documents, and rich GitHub PR body with full change summary.

## senior-reviewer
10-year Java/Spring veteran persona. Reviews: correctness, business logic placement, N+1 queries,
pagination, API semantics, exception completeness, test coverage of edge cases, Kafka idempotency.
Produces actionable blocking issues with before/after code examples.

## architect-reviewer
Principal Architect persona. Reviews: service boundaries, breaking API changes, scalability
(unbounded ops, missing indexes), resilience (circuit breakers, idempotency), security posture,
observability, operational safety of DB/Kafka schema changes.

## ci-monitor
Monitors Jenkins via MCP (30s poll). Diagnoses build failures from console log.
Watches SonarQube quality gate — fixes Blocker/Critical issues, generates coverage tests.
Watches Nexus IQ — auto-bumps CVE-affected deps. Posts final CI report to GitHub PR.

## bugfix-workflow
Dedicated bug fix pipeline — different from feature flow. Stages: parse symptom → write failing
regression test FIRST → trace root cause → impact analysis (find same bug elsewhere) → minimal fix
→ verify regression test passes → standards + senior review (bug-focus) → PR with root cause explanation.
Hotfix flow for Critical severity: branches from main, fast-tracks review, targets main directly.

## refactoring
Pure structural change pipeline. 8 refactoring types: extract service (god class), split controller,
rename package/class, move class, extract interface, replace field injection, extract constants,
decompose long method. Mandatory safety net before any change: measure coverage baseline, confirm
all tests green. Hard rule: zero behavior change, no feature/bug mixing in same PR.

## upgrade-agent
Full Java and Spring Boot version upgrade pipeline. Inputs: GitHub repo URL + base branch +
target Java version + target Spring Boot version. Stages: compatibility check (blocks invalid
paths like Java 8 + SB3) → clone repo → safety net (blocks if baseline build RED) → OpenRewrite
automated migration (javax→jakarta, Security DSL, property renames) → compile error fix loop
→ test failure fix loop → E2E fix → SonarQube scan + fix via MCP → Nexus IQ CVE fix via MCP
→ Jenkins build monitor via MCP (max 5 re-triggers) → PR with full upgrade report.
Hard rules: never start on red baseline, OpenRewrite before manual fixes, never fight Spring Boot
BOM, all 3 gates (Jenkins + Sonar + Nexus) must be GREEN before PR is marked ready.
