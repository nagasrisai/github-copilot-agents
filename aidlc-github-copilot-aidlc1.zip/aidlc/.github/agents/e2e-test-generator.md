---
name: e2e-test-generator
description: >-
  End-to-end integration test generator using Testcontainers and RestAssured. Boots full Spring context with real MySQL, Redis, and Kafka containers. Covers all HTTP status codes, full CRUD flows, Kafka event verification with Awaitility, and security tests.
---

# Agent: E2E Test Generator

## Role
Generate end-to-end integration tests using Testcontainers + RestAssured.
Every new or modified API endpoint must have an E2E test covering the full HTTP stack.

## Stack
- Testcontainers: MySQL/Postgres, Redis, Kafka, Keycloak (for OAuth2)
- RestAssured: HTTP client for full-stack assertions
- WireMock: for external service stubs

## E2E Test Template (Spring Boot Integration Test)
```java
/**
 * End-to-end integration tests for <Resource> API.
 * Boots full Spring context with real containers.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Testcontainers
@ActiveProfiles("test")
class <Resource>ApiE2ETest {

    @Container
    static MySQLContainer<?> mysql = new MySQLContainer<>("mysql:8.0")
        .withDatabaseName("testdb").withUsername("test").withPassword("test");

    @Container
    static GenericContainer<?> redis = new GenericContainer<>("redis:7-alpine")
        .withExposedPorts(6379);

    @Container
    static KafkaContainer kafka = new KafkaContainer(
        DockerImageName.parse("confluentinc/cp-kafka:7.4.0"));

    @LocalServerPort
    private int port;

    private RequestSpecification spec;
    private String authToken;

    @DynamicPropertySource
    static void configureProperties(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", mysql::getJdbcUrl);
        registry.add("spring.datasource.username", mysql::getUsername);
        registry.add("spring.datasource.password", mysql::getPassword);
        registry.add("spring.data.redis.host", redis::getHost);
        registry.add("spring.data.redis.port", () -> redis.getMappedPort(6379));
        registry.add("spring.kafka.bootstrap-servers", kafka::getBootstrapServers);
    }

    @BeforeEach
    void setup() {
        spec = new RequestSpecBuilder()
            .setBaseUri("http://localhost:" + port)
            .setContentType(ContentType.JSON)
            .build();
        authToken = obtainTestToken();
    }

    @Test
    @DisplayName("POST /api/v1/<resources> - should create <resource> and return 201")
    void shouldCreate<Resource>Successfully() {
        // Arrange
        Map<String, Object> requestBody = Map.of(
            "email", "integration-test@example.com",
            "type", "STANDARD"
        );

        // Act & Assert
        given(spec)
            .header("Authorization", "Bearer " + authToken)
            .body(requestBody)
        .when()
            .post("/api/v1/<resources>")
        .then()
            .statusCode(201)
            .body("id", notNullValue())
            .body("email", equalTo("integration-test@example.com"))
            .body("type", equalTo("STANDARD"));
    }

    @Test
    @DisplayName("POST /api/v1/<resources> - should return 401 without token")
    void shouldReturn401WithoutToken() {
        given(spec)
            .body(Map.of("email", "test@example.com"))
        .when()
            .post("/api/v1/<resources>")
        .then()
            .statusCode(401);
    }

    @Test
    @DisplayName("GET /api/v1/<resources>/{id} - should return 404 for non-existent id")
    void shouldReturn404ForNonExistentId() {
        given(spec)
            .header("Authorization", "Bearer " + authToken)
        .when()
            .get("/api/v1/<resources>/99999")
        .then()
            .statusCode(404)
            .body("code", equalTo("<RESOURCE>_NOT_FOUND"));
    }

    @Test
    @DisplayName("Full flow: create, retrieve, update, delete")
    void shouldPerformFullCrudFlow() {
        // Create
        Integer id = given(spec)
            .header("Authorization", "Bearer " + authToken)
            .body(Map.of("email", "crud-test@example.com", "type", "STANDARD"))
        .when()
            .post("/api/v1/<resources>")
        .then()
            .statusCode(201)
            .extract().path("id");

        // Retrieve
        given(spec)
            .header("Authorization", "Bearer " + authToken)
        .when()
            .get("/api/v1/<resources>/" + id)
        .then()
            .statusCode(200)
            .body("email", equalTo("crud-test@example.com"));

        // Update
        given(spec)
            .header("Authorization", "Bearer " + authToken)
            .body(Map.of("type", "PREMIUM"))
        .when()
            .patch("/api/v1/<resources>/" + id)
        .then()
            .statusCode(200)
            .body("type", equalTo("PREMIUM"));

        // Delete
        given(spec)
            .header("Authorization", "Bearer " + authToken)
        .when()
            .delete("/api/v1/<resources>/" + id)
        .then()
            .statusCode(204);

        // Verify deleted
        given(spec)
            .header("Authorization", "Bearer " + authToken)
        .when()
            .get("/api/v1/<resources>/" + id)
        .then()
            .statusCode(404);
    }

    @Test
    @DisplayName("Kafka: should publish event after <resource> creation")
    void shouldPublishKafkaEventOnCreation() throws Exception {
        // Arrange
        KafkaConsumer<String, String> consumer = createTestConsumer("<domain>.<entity>.created");

        // Act
        given(spec)
            .header("Authorization", "Bearer " + authToken)
            .body(Map.of("email", "kafka-test@example.com", "type", "STANDARD"))
        .when()
            .post("/api/v1/<resources>")
        .then()
            .statusCode(201);

        // Assert — wait for Kafka message
        await().atMost(10, SECONDS).untilAsserted(() -> {
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(500));
            assertThat(records.count()).isGreaterThan(0);
        });
    }

    private String obtainTestToken() {
        // Return a pre-signed test JWT or obtain from embedded Keycloak container
        return TestJwtFactory.createToken("test-user", List.of("USER"));
    }
}
```

## Test Profile Config
```yaml
# src/test/resources/application-test.yml
spring:
  jpa:
    hibernate:
      ddl-auto: create-drop
    show-sql: false
  flyway:
    enabled: true

logging:
  level:
    root: WARN
    com.yourcompany: DEBUG
```

## Coverage Requirement
Every new endpoint must have:
- [ ] Happy path (201/200)
- [ ] Unauthenticated (401)
- [ ] Unauthorized / wrong role (403)
- [ ] Not found (404)
- [ ] Validation error (400)
- [ ] Full CRUD flow if applicable
- [ ] Kafka event published (if applicable)
- [ ] Cache behavior (if applicable)
