#!/usr/bin/env bash
# setup-mcp-servers.sh — Install and configure all MCP servers for AIDLC
# Run once during environment setup

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()    { echo -e "${BLUE}[MCP Setup]${NC} $*"; }
success(){ echo -e "${GREEN}[MCP Setup]${NC} $*"; }
warn()   { echo -e "${YELLOW}[MCP Setup]${NC} $*"; }
error()  { echo -e "${RED}[MCP Setup]${NC} $*" >&2; }

# Check node/npm available
check_prerequisites() {
  for tool in node npm gh git; do
    if ! command -v "$tool" &>/dev/null; then
      error "Required tool missing: $tool"
      exit 1
    fi
  done
  log "Prerequisites OK"
}

# Install Jira MCP server
install_jira_mcp() {
  log "Installing Jira MCP server..."
  npm install -g @modelcontextprotocol/server-jira 2>/dev/null || \
  npm install -g jira-mcp-server 2>/dev/null || \
  warn "Auto-install failed. Manual install: https://github.com/sooperset/mcp-atlassian"

  # Write config
  cat > ~/.config/mcp/jira.json << EOF
{
  "name": "jira-mcp-server",
  "command": "npx",
  "args": ["-y", "@sooperset/mcp-atlassian"],
  "env": {
    "JIRA_URL": "${JIRA_BASE_URL}",
    "JIRA_USERNAME": "${JIRA_EMAIL}",
    "JIRA_API_TOKEN": "${JIRA_API_TOKEN}"
  }
}
EOF
  success "Jira MCP configured"
}

# Install Jenkins MCP server
install_jenkins_mcp() {
  log "Installing Jenkins MCP server..."
  npm install -g jenkins-mcp-server 2>/dev/null || \
  warn "Auto-install failed. Use: https://github.com/jenkins-infra/jenkins-mcp"

  cat > ~/.config/mcp/jenkins.json << EOF
{
  "name": "jenkins-mcp-server",
  "command": "npx",
  "args": ["-y", "jenkins-mcp-server"],
  "env": {
    "JENKINS_URL": "${JENKINS_URL}",
    "JENKINS_USERNAME": "${JENKINS_USER}",
    "JENKINS_TOKEN": "${JENKINS_TOKEN}"
  }
}
EOF
  success "Jenkins MCP configured"
}

# Install SonarQube MCP server
install_sonar_mcp() {
  log "Installing SonarQube MCP server..."
  npm install -g sonarqube-mcp-server 2>/dev/null || \
  warn "Auto-install failed. Use: https://github.com/SonarSource/sonarqube-mcp-server"

  cat > ~/.config/mcp/sonarqube.json << EOF
{
  "name": "sonarqube-mcp-server",
  "command": "npx",
  "args": ["-y", "sonarqube-mcp-server"],
  "env": {
    "SONAR_URL": "${SONAR_URL}",
    "SONAR_TOKEN": "${SONAR_TOKEN}"
  }
}
EOF
  success "SonarQube MCP configured"
}

# Nexus IQ — REST API based (no dedicated MCP yet — use HTTP MCP proxy)
install_nexus_mcp() {
  log "Configuring Nexus IQ via REST MCP proxy..."
  npm install -g @modelcontextprotocol/server-fetch 2>/dev/null || true

  cat > ~/.config/mcp/nexus-iq.json << EOF
{
  "name": "nexus-iq-rest",
  "description": "Nexus IQ REST API proxy via fetch MCP",
  "command": "npx",
  "args": ["-y", "@modelcontextprotocol/server-fetch"],
  "env": {
    "NEXUS_IQ_BASE_URL": "${NEXUS_IQ_URL}",
    "NEXUS_IQ_USER": "${NEXUS_IQ_USER}",
    "NEXUS_IQ_PASSWORD": "${NEXUS_IQ_PASSWORD}"
  }
}
EOF
  success "Nexus IQ MCP configured (REST proxy)"
}

# GitHub MCP (official)
install_github_mcp() {
  log "Installing GitHub MCP server (official)..."
  npm install -g @modelcontextprotocol/server-github 2>/dev/null || \
  npm install -g @github/github-mcp-server 2>/dev/null || \
  warn "Auto-install failed. Use: https://github.com/github/github-mcp-server"

  cat > ~/.config/mcp/github.json << EOF
{
  "name": "github-mcp-server",
  "command": "npx",
  "args": ["-y", "@modelcontextprotocol/server-github"],
  "env": {
    "GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}"
  }
}
EOF
  success "GitHub MCP configured"
}

# Write combined MCP config for VS Code / Copilot Chat
write_vscode_mcp_config() {
  log "Writing VS Code MCP config (.vscode/mcp.json)..."
  mkdir -p .vscode

  cat > .vscode/mcp.json << EOF
{
  "servers": {
    "jira": {
      "command": "npx",
      "args": ["-y", "@sooperset/mcp-atlassian"],
      "env": {
        "JIRA_URL": "\${env:JIRA_BASE_URL}",
        "JIRA_USERNAME": "\${env:JIRA_EMAIL}",
        "JIRA_API_TOKEN": "\${env:JIRA_API_TOKEN}"
      }
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "\${env:GITHUB_TOKEN}"
      }
    },
    "jenkins": {
      "command": "npx",
      "args": ["-y", "jenkins-mcp-server"],
      "env": {
        "JENKINS_URL": "\${env:JENKINS_URL}",
        "JENKINS_USERNAME": "\${env:JENKINS_USER}",
        "JENKINS_TOKEN": "\${env:JENKINS_TOKEN}"
      }
    },
    "sonarqube": {
      "command": "npx",
      "args": ["-y", "sonarqube-mcp-server"],
      "env": {
        "SONAR_URL": "\${env:SONAR_URL}",
        "SONAR_TOKEN": "\${env:SONAR_TOKEN}"
      }
    }
  }
}
EOF
  success ".vscode/mcp.json written"
}

# Validate all env vars are set
validate_env() {
  log "Validating environment variables..."
  local missing=()
  local vars=(
    JIRA_BASE_URL JIRA_API_TOKEN JIRA_EMAIL JIRA_PROJECT_KEY
    JENKINS_URL JENKINS_USER JENKINS_TOKEN
    SONAR_URL SONAR_TOKEN SONAR_PROJECT_KEY
    NEXUS_IQ_URL NEXUS_IQ_USER NEXUS_IQ_PASSWORD NEXUS_APP_ID
    GITHUB_TOKEN
  )
  for var in "${vars[@]}"; do
    if [[ -z "${!var:-}" ]]; then
      missing+=("$var")
    fi
  done

  if [[ ${#missing[@]} -gt 0 ]]; then
    warn "Missing environment variables:"
    for var in "${missing[@]}"; do
      warn "  export $var=<value>"
    done
    warn ""
    warn "Set these in your shell profile or GitHub repository secrets."
    warn "Reference: .github/instructions/mcp-wiring.md"
    return 1
  fi
  success "All environment variables set"
}

main() {
  log "Setting up AIDLC MCP servers..."
  mkdir -p ~/.config/mcp

  check_prerequisites
  validate_env || warn "Proceeding with missing vars — update them before running AIDLC"

  install_jira_mcp
  install_jenkins_mcp
  install_sonar_mcp
  install_nexus_mcp
  install_github_mcp
  write_vscode_mcp_config

  echo ""
  success "MCP setup complete!"
  log "Next step: Open this repo in VS Code with GitHub Copilot extension"
  log "Run: .github/scripts/aidlc.sh bootstrap"
  log "Then: .github/scripts/aidlc.sh start"
}

main "$@"
