#!/usr/bin/env bash
# aidlc.sh — AIDLC pipeline entry point
# Usage:
#   aidlc.sh start                           # interactive
#   aidlc.sh start --ticket PROJ-123         # from Jira ticket
#   aidlc.sh start --prompt "add OTP login"  # from free text
#   aidlc.sh resume run-2026-05-16-001       # resume interrupted run
#   aidlc.sh bootstrap                       # first-time setup
#   aidlc.sh status                          # show current run state
#   aidlc.sh list                            # list all runs

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
GITHUB_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
REPO_ROOT="$(cd "$GITHUB_DIR/.." && pwd)"
AIDLC_DIR="$REPO_ROOT/.aidlc"
RUNS_DIR="$AIDLC_DIR/runs"

# Colors
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'

log()    { echo -e "${BLUE}[AIDLC]${NC} $*"; }
success(){ echo -e "${GREEN}[AIDLC]${NC} $*"; }
warn()   { echo -e "${YELLOW}[AIDLC]${NC} $*"; }
error()  { echo -e "${RED}[AIDLC]${NC} $*" >&2; }

# Generate unique run ID
generate_run_id() {
  echo "run-$(date +%Y-%m-%d)-$(printf '%03d' "$((RANDOM % 1000))")"
}

# Bootstrap: first-time setup
cmd_bootstrap() {
  log "Bootstrapping AIDLC environment..."

  # Check required tools
  for tool in git gh jq mvn; do
    if ! command -v "$tool" &>/dev/null; then
      error "Required tool not found: $tool"
      exit 1
    fi
  done

  # Create .aidlc directory structure
  mkdir -p "$AIDLC_DIR/runs"
  mkdir -p "$AIDLC_DIR/templates"

  # Create .aidlc/.gitignore (don't commit run state)
  cat > "$AIDLC_DIR/.gitignore" << 'EOF'
runs/
*.log
EOF

  # Validate required environment variables
  local missing=()
  for var in JIRA_BASE_URL JIRA_API_TOKEN JENKINS_URL JENKINS_TOKEN SONAR_URL SONAR_TOKEN NEXUS_IQ_URL GITHUB_TOKEN; do
    if [[ -z "${!var:-}" ]]; then
      missing+=("$var")
    fi
  done

  if [[ ${#missing[@]} -gt 0 ]]; then
    warn "Missing environment variables (set in GitHub Secrets or .env):"
    for var in "${missing[@]}"; do
      warn "  - $var"
    done
    warn "See .github/instructions/mcp-wiring.md for details."
  fi

  # Detect repo stack
  detect_stack

  success "Bootstrap complete. Run: aidlc.sh start"
}

# Detect Java/Spring stack
detect_stack() {
  log "Detecting project stack..."

  if [[ -f "$REPO_ROOT/pom.xml" ]]; then
    BUILD_TOOL="maven"
    JAVA_VERSION=$(grep -m1 '<java.version>' "$REPO_ROOT/pom.xml" | grep -oP '\d+' | head -1 || echo "17")
    SPRING_VERSION=$(grep -m1 'spring-boot' "$REPO_ROOT/pom.xml" | grep -oP '\d+\.\d+\.\d+' | head -1 || echo "3.x")
  elif [[ -f "$REPO_ROOT/build.gradle" ]] || [[ -f "$REPO_ROOT/build.gradle.kts" ]]; then
    BUILD_TOOL="gradle"
    JAVA_VERSION=$(grep -m1 'sourceCompatibility\|javaVersion\|JavaVersion.VERSION' "$REPO_ROOT/build.gradle" 2>/dev/null | grep -oP '\d+' | head -1 || echo "17")
    SPRING_VERSION=$(grep -m1 'spring-boot' "$REPO_ROOT/build.gradle" 2>/dev/null | grep -oP '\d+\.\d+\.\d+' | head -1 || echo "3.x")
  else
    BUILD_TOOL="unknown"
    JAVA_VERSION="17"
    SPRING_VERSION="3.x"
    warn "Could not detect build tool — defaulting to Java 17 / Spring Boot 3.x"
  fi

  log "Stack detected: Java $JAVA_VERSION | Spring Boot $SPRING_VERSION | $BUILD_TOOL"
  export BUILD_TOOL JAVA_VERSION SPRING_VERSION
}

# Init run state
init_run_state() {
  local run_id="$1" input_type="$2" input_ref="$3"
  local state_file="$RUNS_DIR/$run_id/state.json"

  mkdir -p "$RUNS_DIR/$run_id"

  cat > "$state_file" << EOF
{
  "run_id": "$run_id",
  "input_type": "$input_type",
  "input_ref": "$input_ref",
  "status": "intake",
  "branch": "",
  "java_version": "${JAVA_VERSION:-17}",
  "spring_version": "${SPRING_VERSION:-3.x}",
  "build_tool": "${BUILD_TOOL:-maven}",
  "started_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "checkpoints": { "C1": false, "C2": false, "C3": false, "C4": false, "C5": false },
  "agents_completed": [],
  "review_iterations": { "senior": 0, "architect": 0 },
  "issues": []
}
EOF
  echo "$state_file"
}

update_state() {
  local run_id="$1" field="$2" value="$3"
  local state_file="$RUNS_DIR/$run_id/state.json"
  local tmp
  tmp=$(mktemp)
  jq ".$field = $value" "$state_file" > "$tmp" && mv "$tmp" "$state_file"
}

# Human checkpoint
checkpoint() {
  local id="$1" question="$2"
  echo ""
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo -e "${YELLOW}  CHECKPOINT $id${NC}"
  echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
  echo ""
  read -rp "  $question [y/N]: " answer
  echo ""
  [[ "$answer" =~ ^[Yy]$ ]]
}

# Main start command
cmd_start() {
  local input_type="" input_ref="" ticket="" prompt_text="" pipeline=""

  # Parse args
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --ticket)   ticket="$2";       shift 2 ;;
      --prompt)   prompt_text="$2";  shift 2 ;;
      --bugfix)   pipeline="bugfix"; shift ;;
      --refactor) pipeline="refactor"; shift ;;
      --upgrade)  pipeline="upgrade"; shift ;;
      *) shift ;;
    esac
  done

  # Determine input type
  if [[ -n "$ticket" ]]; then
    input_type="jira"
    input_ref="$ticket"
  elif [[ -n "$prompt_text" ]]; then
    input_type="prompt"
    input_ref="$prompt_text"
  else
    input_type="interactive"
    echo ""
    log "AIDLC — AI-Driven Development Lifecycle"
    echo ""
    echo "What type of work?"
    echo "  1) Feature (Jira ticket)"
    echo "  2) Feature (describe in prompt)"
    echo "  3) Bug fix (Jira ticket)"
    echo "  4) Bug fix (describe the issue)"
    echo "  5) Refactoring (Jira tech-debt ticket)"
    echo "  6) Refactoring (describe what to refactor)"
    echo "  7) Upgrade Java / Spring Boot version"
    echo ""
    read -rp "Choice [1-7]: " choice
    case "$choice" in
      1) read -rp "Jira ticket key: " ticket; input_ref="$ticket"; input_type="jira" ;;
      2) read -rp "Describe the feature: " prompt_text; input_ref="$prompt_text"; input_type="prompt" ;;
      3) read -rp "Jira bug ticket key: " ticket; input_ref="$ticket"; input_type="jira"; pipeline="bugfix" ;;
      4) read -rp "Describe the bug: " prompt_text; input_ref="$prompt_text"; input_type="prompt"; pipeline="bugfix" ;;
      5) read -rp "Jira tech-debt ticket key: " ticket; input_ref="$ticket"; input_type="jira"; pipeline="refactor" ;;
      6) read -rp "Describe the refactoring: " prompt_text; input_ref="$prompt_text"; input_type="prompt"; pipeline="refactor" ;;
      7)
        read -rp "GitHub repo URL: " repo_url
        read -rp "Base branch (e.g. develop, main): " base_branch
        read -rp "Target Java version (e.g. 17, 21): " target_java
        read -rp "Target Spring Boot version (e.g. 3.2.5): " target_spring
        input_ref="repo=$repo_url base=$base_branch java=$target_java spring=$target_spring"
        input_type="prompt"
        pipeline="upgrade"
        ;;
    esac
  fi

  # Auto-detect pipeline from prompt keywords if not explicitly set
  if [[ -z "$pipeline" ]]; then
    if echo "$input_ref" | grep -qiE "fix|bug|broken|error|exception|failing|wrong|crash|npe|stack.?trace"; then
      pipeline="bugfix"
      log "Detected: Bug Fix pipeline"
    elif echo "$input_ref" | grep -qiE "refactor|extract|split|rename|restructure|too.?big|god.?class|move.?class|field.?injection|clean.?up"; then
      pipeline="refactor"
      log "Detected: Refactoring pipeline"
    elif echo "$input_ref" | grep -qiE "upgrade.?java|upgrade.?spring|migrate.?to.?java|java.?17|java.?21|spring.?boot.?3|bump.?java|bump.?spring"; then
      pipeline="upgrade"
      log "Detected: Upgrade pipeline"
    else
      pipeline="feature"
    fi
  fi

  detect_stack

  local run_id
  run_id=$(generate_run_id)
  local state_file
  state_file=$(init_run_state "$run_id" "$input_type" "$input_ref")

  # Select prompt template based on pipeline
  local prompt_file
  case "$pipeline" in
    bugfix)   prompt_file="$GITHUB_DIR/prompts/start-bugfix.prompt.md" ;;
    refactor) prompt_file="$GITHUB_DIR/prompts/start-refactor.prompt.md" ;;
    upgrade)  prompt_file="$GITHUB_DIR/prompts/start-upgrade.prompt.md" ;;
    *)        
      if [[ "$input_type" == "jira" ]]; then
        prompt_file="$GITHUB_DIR/prompts/start-from-jira.prompt.md"
      else
        prompt_file="$GITHUB_DIR/prompts/start-from-prompt.prompt.md"
      fi ;;
  esac

  log "Pipeline: $pipeline | Input: [$input_type] $input_ref"
  log "Loading: $prompt_file"

  # Build the copilot invocation
  local copilot_prompt
  copilot_prompt="$(cat "$prompt_file")"
  copilot_prompt="${copilot_prompt//\{\{TICKET_KEY\}\}/$input_ref}"
  copilot_prompt="${copilot_prompt//\{\{USER_PROMPT\}\}/$input_ref}"
  copilot_prompt="${copilot_prompt//\{\{BUG_INPUT\}\}/$input_ref}"
  copilot_prompt="${copilot_prompt//\{\{REFACTOR_INPUT\}\}/$input_ref}"
  copilot_prompt="${copilot_prompt//\{\{RUN_ID\}\}/$run_id}"

  # Invoke GitHub Copilot CLI
  if command -v gh &>/dev/null && gh extension list 2>/dev/null | grep -q copilot; then
    gh copilot suggest "$copilot_prompt" --target shell
  else
    warn "GitHub Copilot CLI not found. Prompt saved to:"
    warn "  $RUNS_DIR/$run_id/orchestrator-prompt.md"
    warn "Paste it into your Copilot Chat session to start the pipeline."
  fi
}

# Resume an interrupted run
cmd_resume() {
  local run_id="${1:-}"
  if [[ -z "$run_id" ]]; then
    error "Usage: aidlc.sh resume <run-id>"
    cmd_list
    exit 1
  fi

  local state_file="$RUNS_DIR/$run_id/state.json"
  if [[ ! -f "$state_file" ]]; then
    error "Run not found: $run_id"
    exit 1
  fi

  local status
  status=$(jq -r '.status' "$state_file")
  log "Resuming run $run_id at stage: $status"

  local resume_prompt="Resume AIDLC run $run_id. Load state from .aidlc/runs/$run_id/state.json. Current stage: $status. Continue from where we left off."
  echo "$resume_prompt" > "$RUNS_DIR/$run_id/resume-prompt.md"

  if command -v gh &>/dev/null && gh extension list 2>/dev/null | grep -q copilot; then
    gh copilot suggest "$resume_prompt" --target shell
  else
    warn "Paste the resume prompt into Copilot Chat:"
    cat "$RUNS_DIR/$run_id/resume-prompt.md"
  fi
}

# Show current run status
cmd_status() {
  local latest_run
  latest_run=$(ls -t "$RUNS_DIR" 2>/dev/null | head -1)

  if [[ -z "$latest_run" ]]; then
    log "No runs found."
    return
  fi

  local state_file="$RUNS_DIR/$latest_run/state.json"
  echo ""
  log "Latest run: $latest_run"
  jq '{run_id, status, input_type, input_ref, branch, agents_completed, checkpoints}' "$state_file"
}

# List all runs
cmd_list() {
  echo ""
  log "All AIDLC runs:"
  if [[ ! -d "$RUNS_DIR" ]] || [[ -z "$(ls -A "$RUNS_DIR" 2>/dev/null)" ]]; then
    log "  No runs yet."
    return
  fi
  for run_dir in "$RUNS_DIR"/*/; do
    local run_id
    run_id=$(basename "$run_dir")
    local status
    status=$(jq -r '.status // "unknown"' "$run_dir/state.json" 2>/dev/null)
    local input_ref
    input_ref=$(jq -r '.input_ref // ""' "$run_dir/state.json" 2>/dev/null)
    printf "  %-30s %-15s %s\n" "$run_id" "[$status]" "$input_ref"
  done
}

# Main dispatch
main() {
  local cmd="${1:-help}"
  shift || true

  case "$cmd" in
    start)     cmd_start "$@" ;;
    resume)    cmd_resume "$@" ;;
    bootstrap) cmd_bootstrap ;;
    status)    cmd_status ;;
    list)      cmd_list ;;
    help|--help|-h)
      echo ""
      echo "AIDLC — AI-Driven Development Lifecycle"
      echo ""
      echo "Commands:"
      echo "  bootstrap                           First-time setup, validate environment"
      echo "  start                               Start interactive pipeline (auto-detects type)"
      echo "  start --ticket PROJ-123             Feature from Jira ticket"
      echo "  start --prompt 'add OTP'            Feature from free-text requirement"
      echo "  start --ticket PROJ-456 --bugfix    Bug fix from Jira ticket"
      echo "  start --prompt 'NPE in...' --bugfix Bug fix from description / stack trace"
      echo "  start --ticket PROJ-789 --refactor  Refactoring from Jira tech-debt ticket"
      echo "  start --prompt 'split UserService' --refactor  Refactoring from description"
      echo "  start --upgrade                     Upgrade Java/Spring Boot (interactive)"
      echo "  start --prompt 'upgrade to java 21 spring 3.2.5' --upgrade"
      echo "  resume <run-id>                     Resume interrupted run"
      echo "  status                              Show latest run status"
      echo "  list                                List all runs"
      echo ""
      echo "Pipeline auto-detection (no flag needed):"
      echo "  Keywords like 'fix', 'bug', 'error', 'crash'      → Bug Fix pipeline"
      echo "  Keywords like 'refactor', 'split', 'extract'      → Refactoring pipeline"
      echo "  Everything else                                     → Feature pipeline"
      echo ""
      ;;
    *) error "Unknown command: $cmd. Run: aidlc.sh help" ;;
  esac
}

main "$@"
