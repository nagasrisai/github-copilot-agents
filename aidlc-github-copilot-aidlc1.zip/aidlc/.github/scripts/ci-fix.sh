#!/usr/bin/env bash
# ci-fix.sh — Called by AIDLC CI Monitor to diagnose and fix Jenkins failures
# Usage: ci-fix.sh <jenkins-job> <build-number> <run-id>

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
log()    { echo -e "${BLUE}[CI Fix]${NC} $*"; }
success(){ echo -e "${GREEN}[CI Fix]${NC} $*"; }
warn()   { echo -e "${YELLOW}[CI Fix]${NC} $*"; }
error()  { echo -e "${RED}[CI Fix]${NC} $*" >&2; }

JOB="${1:-}"
BUILD_NUMBER="${2:-}"
RUN_ID="${3:-}"

if [[ -z "$JOB" || -z "$BUILD_NUMBER" || -z "$RUN_ID" ]]; then
  error "Usage: ci-fix.sh <job> <build-number> <run-id>"
  exit 1
fi

RUNS_DIR="$REPO_ROOT/.aidlc/runs"
CONSOLE_LOG="$RUNS_DIR/$RUN_ID/jenkins-console.log"
FIX_REPORT="$RUNS_DIR/$RUN_ID/ci-fix-report.md"

# Fetch Jenkins console log
fetch_console() {
  log "Fetching Jenkins console log: $JOB #$BUILD_NUMBER"
  curl -s -u "$JENKINS_USER:$JENKINS_TOKEN" \
    "$JENKINS_URL/job/$JOB/$BUILD_NUMBER/consoleText" > "$CONSOLE_LOG"
  log "Console log saved: $CONSOLE_LOG"
}

# Diagnose failure from console log
diagnose() {
  log "Diagnosing failure..."
  local diagnosis=""

  if grep -q "Tests run:.*Failures:" "$CONSOLE_LOG" 2>/dev/null; then
    diagnosis="TEST_FAILURE"
    FAILING_TEST=$(grep -m1 "FAILED\|<<<.*FAILED" "$CONSOLE_LOG" | head -1 || echo "unknown")
    log "Test failure detected: $FAILING_TEST"

  elif grep -q "COMPILATION ERROR\|cannot find symbol\|error: " "$CONSOLE_LOG" 2>/dev/null; then
    diagnosis="COMPILE_ERROR"
    COMPILE_ERROR=$(grep -m3 "error:" "$CONSOLE_LOG" | head -3 || echo "unknown")
    log "Compilation error detected"

  elif grep -q "Cannot resolve\|Could not resolve\|Could not find artifact" "$CONSOLE_LOG" 2>/dev/null; then
    diagnosis="DEPENDENCY_ERROR"
    log "Dependency resolution error detected"

  elif grep -q "OutOfMemoryError\|GC overhead limit exceeded" "$CONSOLE_LOG" 2>/dev/null; then
    diagnosis="OOM"
    log "Out of memory error detected"

  elif grep -q "Connection refused\|ConnectException" "$CONSOLE_LOG" 2>/dev/null; then
    diagnosis="CONNECTION_ERROR"
    log "Connection refused — likely external dependency in test"

  elif grep -q "checkstyle\|Checkstyle" "$CONSOLE_LOG" 2>/dev/null; then
    diagnosis="CHECKSTYLE"
    log "Checkstyle violation detected"

  elif grep -q "Address already in use\|Port.*already in use" "$CONSOLE_LOG" 2>/dev/null; then
    diagnosis="PORT_CONFLICT"
    log "Port conflict detected in tests"

  else
    diagnosis="UNKNOWN"
    warn "Could not determine failure cause. Manual review required."
  fi

  echo "$diagnosis"
}

# Apply fix based on diagnosis
apply_fix() {
  local diagnosis="$1"
  local fixed=false

  case "$diagnosis" in
    TEST_FAILURE)
      log "Preparing test fix prompt for Copilot..."
      cat > "$RUNS_DIR/$RUN_ID/ci-fix-prompt.md" << EOF
The Jenkins CI build failed due to unit test failures.

Console log excerpt:
$(grep -A5 "Tests run:.*Failures:" "$CONSOLE_LOG" | head -20)

Failed test: $(grep -m1 "FAILED" "$CONSOLE_LOG" || echo "check console log")

Load: .github/agents/ci-monitor.md
Fix the failing tests. The tests must pass. Do not delete tests — fix the underlying code or the test assertion.
Commit message: "fix(ci): fix failing unit tests"
EOF
      fixed=true
      ;;

    COMPILE_ERROR)
      log "Preparing compile fix prompt for Copilot..."
      cat > "$RUNS_DIR/$RUN_ID/ci-fix-prompt.md" << EOF
The Jenkins CI build failed with a compilation error.

Error details:
$(grep -A3 "error:" "$CONSOLE_LOG" | head -15)

Load: .github/agents/java-standards.md
Fix the compilation errors. Verify imports, types, and syntax.
Commit message: "fix(ci): fix compilation errors"
EOF
      fixed=true
      ;;

    OOM)
      log "Applying OOM fix — increasing Maven/Gradle heap..."
      if [[ -f "$REPO_ROOT/Jenkinsfile" ]]; then
        sed -i "s/MAVEN_OPTS='-Xmx[0-9]*m'/MAVEN_OPTS='-Xmx2048m'/g" "$REPO_ROOT/Jenkinsfile" || true
        sed -i "s/JAVA_OPTS='-Xmx[0-9]*m'/JAVA_OPTS='-Xmx2048m'/g" "$REPO_ROOT/Jenkinsfile" || true
      fi
      cat > "$REPO_ROOT/.mvn/jvm.config" << 'EOF'
-Xmx2048m
-XX:MaxMetaspaceSize=512m
-XX:+UseG1GC
EOF
      git -C "$REPO_ROOT" add .mvn/jvm.config Jenkinsfile 2>/dev/null || true
      fixed=true
      ;;

    CONNECTION_ERROR)
      warn "External connection failure in tests — likely test env config issue"
      warn "Auto-fix: adding @Tag(\"integration\") to affected tests for conditional skip in CI"
      cat > "$RUNS_DIR/$RUN_ID/ci-fix-prompt.md" << EOF
The Jenkins CI build failed because a test is trying to connect to an external service that's not available in CI.

Console log:
$(grep -B2 -A5 "Connection refused\|ConnectException" "$CONSOLE_LOG" | head -20)

Load: .github/agents/ci-monitor.md
Find the test(s) causing this and either:
1. Mock the external call with @MockBean / WireMock
2. Add @Tag("integration") and configure CI to skip integration tests
3. Add @ConditionalOnProperty to make the test skip when the service is unavailable

Commit message: "fix(ci): mock external service in tests"
EOF
      fixed=true
      ;;

    PORT_CONFLICT)
      log "Fixing port conflict — adding random port config to tests..."
      find "$REPO_ROOT/src/test" -name "*.java" -exec grep -l "@SpringBootTest" {} \; | while read -r f; do
        sed -i 's/@SpringBootTest$/@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)/g' "$f"
        sed -i 's/@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)/@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)/g' "$f"
      done
      git -C "$REPO_ROOT" add -u
      fixed=true
      ;;

    UNKNOWN)
      warn "Unknown failure — generating analysis prompt"
      cat > "$RUNS_DIR/$RUN_ID/ci-fix-prompt.md" << EOF
The Jenkins CI build failed for an unknown reason.

Full console log (last 50 lines):
$(tail -50 "$CONSOLE_LOG")

Load: .github/agents/ci-monitor.md
Analyze the console log and determine the root cause.
Apply the fix, commit with message: "fix(ci): resolve build failure"
EOF
      fixed=true
      ;;
  esac

  echo "$fixed"
}

# Write fix report
write_report() {
  local diagnosis="$1" fixed="$2"
  cat > "$FIX_REPORT" << EOF
# CI Fix Report

## Build
- Job: $JOB
- Build: #$BUILD_NUMBER
- Run ID: $RUN_ID

## Diagnosis
**Failure type**: $diagnosis

## Fix Applied
**Auto-fix**: $fixed

$(if [[ -f "$RUNS_DIR/$RUN_ID/ci-fix-prompt.md" ]]; then
  echo "**Copilot fix prompt generated**: .aidlc/runs/$RUN_ID/ci-fix-prompt.md"
fi)

## Next Steps
$(if [[ "$fixed" == "true" ]]; then
  echo "1. Review the fix applied or the Copilot prompt generated"
  echo "2. Checkpoint C5: Re-trigger Jenkins build? [y/N]"
else
  echo "Manual intervention required — auto-fix was not possible"
fi)
EOF

  log "Fix report written: $FIX_REPORT"
}

# Main
fetch_console
DIAGNOSIS=$(diagnose)
FIXED=$(apply_fix "$DIAGNOSIS")
write_report "$DIAGNOSIS" "$FIXED"

if [[ "$FIXED" == "true" ]]; then
  success "Fix applied for: $DIAGNOSIS"
  log "Review: $FIX_REPORT"
  exit 0
else
  warn "Could not auto-fix: $DIAGNOSIS"
  log "Manual review required: $CONSOLE_LOG"
  exit 1
fi
